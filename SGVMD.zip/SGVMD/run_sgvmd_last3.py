# -*- coding: utf-8 -*-
"""Run the last three nonstationary scenarios using SGVMD only."""
from benchmark_scenarios import all_benchmark_cases
from run_sgvmd_first60 import run_cases


def main():
    cases = all_benchmark_cases()[60:63]
    if len(cases) != 3:
        raise RuntimeError(f"Expected 3 cases, got {len(cases)}")
    run_cases(cases, 61)


if __name__ == "__main__":
    main()
