# -*- coding: utf-8 -*-
"""Unified 25-scenario library + single-channel STVMD paper simulations.

The first 25 cases form the cross-domain benchmark used in this project.
The final four cases are single-channel stationary/non-stationary STVMD-style
synthetic environments used for a consistent univariate comparison.
"""
from __future__ import annotations
import math
import numpy as np
from scipy.signal import chirp
from scipy.optimize import linear_sum_assignment
EPS=np.finfo(float).eps

def add_noise(clean: np.ndarray, snr_db: float | None, seed: int, noise_type: str) -> np.ndarray:
    if snr_db is None:
        return np.asarray(clean, float).copy()
    rng = np.random.default_rng(seed)
    n = len(clean)
    if noise_type == "gaussian":
        noise = rng.standard_normal(n)
    elif noise_type == "colored":
        e = rng.standard_normal(n)
        noise = np.zeros(n)
        for i in range(1, n):
            noise[i] = 0.88 * noise[i - 1] + e[i]
    elif noise_type == "impulsive":
        noise = 0.20 * rng.standard_normal(n)
        count = max(1, n // 120)
        idx = rng.choice(n, size=count, replace=False)
        noise[idx] += 7.5 * rng.standard_normal(count)
    else:
        raise ValueError(noise_type)
    target = np.mean(clean ** 2) / (10.0 ** (snr_db / 10.0))
    noise *= math.sqrt(target / (np.mean(noise ** 2) + EPS))
    return clean + noise


def scenario_library():
    """Exact 25-scenario library used for the cross-domain validation."""
    cases = []
    def add(domain, scenario, slug, fs, truth, snr, noise):
        cases.append(dict(domain=domain, scenario=scenario, slug=slug,
                          fs=float(fs), truth=np.asarray(truth, float),
                          snr=float(snr), noise_type=noise))

    # 1-9: generic / stress
    fs, n = 512.0, 4096
    t = np.arange(n) / fs
    add("通用", "多尺度三频", "multiscale_three_frequency", fs, np.vstack([
        1.15*np.sin(2*np.pi*3*t),
        0.85*np.cos(2*np.pi*28*t + 0.25),
        0.65*np.sin(2*np.pi*95*t + 0.60)]), 20.0, "gaussian")
    add("通用", "1Hz近频", "close_1Hz", fs, np.vstack([
        np.sin(2*np.pi*18*t),
        0.85*np.cos(2*np.pi*19*t + 0.2),
        0.65*np.sin(2*np.pi*70*t + 0.4)]), 20.0, "gaussian")
    add("压力测试", "0.5Hz极近频", "close_0p5Hz", fs, np.vstack([
        np.sin(2*np.pi*18*t),
        0.85*np.cos(2*np.pi*18.5*t + 0.2),
        0.65*np.sin(2*np.pi*70*t + 0.4)]), 20.0, "gaussian")
    add("通用", "AM_FM混合", "am_fm_mixed", fs, np.vstack([
        (1 + 0.35*np.cos(2*np.pi*1.2*t))*np.sin(2*np.pi*20*t),
        0.80*np.sin(2*np.pi*55*t + 2.4*np.sin(2*np.pi*0.75*t)),
        0.55*np.cos(2*np.pi*95*t + 0.4)]), 20.0, "gaussian")
    env = np.exp(-0.5*((t - 4.8)/0.65)**2)
    add("通用", "Chirp加瞬态", "chirp_transient", fs, np.vstack([
        chirp(t, f0=5, f1=35, t1=t[-1], method="linear"),
        0.9*env*np.sin(2*np.pi*75*t),
        0.55*np.cos(2*np.pi*115*t + 0.3)]), 20.0, "gaussian")
    add("压力测试", "弱模态", "weak_mode", fs, np.vstack([
        1.0*np.sin(2*np.pi*10*t),
        0.75*np.cos(2*np.pi*45*t + 0.25),
        0.12*np.sin(2*np.pi*90*t + 0.5)]), 15.0, "gaussian")
    base_noise_truth = np.vstack([
        np.sin(2*np.pi*7*t),
        0.8*np.cos(2*np.pi*32*t + 0.2),
        0.6*np.sin(2*np.pi*88*t + 0.5)])
    add("压力测试", "0dB强噪声", "noise_0dB", fs, base_noise_truth, 0.0, "gaussian")
    add("压力测试", "有色噪声", "colored_noise", fs, base_noise_truth, 15.0, "colored")
    add("压力测试", "脉冲噪声", "impulsive_noise", fs, base_noise_truth, 15.0, "impulsive")

    # 10-13: mechanical
    fs, n = 1024.0, 4096
    t = np.arange(n) / fs
    shaft = 0.80*np.sin(2*np.pi*12*t)
    gear = 0.55*(1 + 0.25*np.cos(2*np.pi*12*t))*np.sin(2*np.pi*96*t + 0.2)
    bearing = np.zeros(n)
    for ti in np.arange(0.15, t[-1], 1/8.0):
        tau = t - ti
        mask = tau >= 0
        bearing[mask] += 0.22*np.exp(-45*tau[mask])*np.sin(2*np.pi*180*tau[mask])
    add("机械", "轴承齿轮复合振动", "bearing_gear_vibration", fs,
        np.vstack([shaft, gear, bearing]), 15.0, "gaussian")
    shaft = 0.50*np.sin(2*np.pi*10*t)
    mesh = 0.90*(1 + 0.30*np.cos(2*np.pi*10*t))*np.cos(2*np.pi*120*t)
    resonance = 0.35*np.cos(2*np.pi*210*t + 0.5)
    add("机械", "齿轮箱调幅边带", "gearbox_am_sidebands", fs,
        np.vstack([shaft, mesh, resonance]), 18.0, "gaussian")
    add("机械", "电机电流故障边带", "motor_current_sidebands", fs, np.vstack([
        1.0*np.sin(2*np.pi*50*t),
        0.18*np.sin(2*np.pi*48*t + 0.2),
        0.16*np.sin(2*np.pi*52*t + 0.5)]), 20.0, "gaussian")
    fs, n = 256.0, 4096
    t = np.arange(n) / fs
    add("机械", "风机1P_3P齿轮", "wind_turbine_1P_3P_gear", fs, np.vstack([
        0.9*np.sin(2*np.pi*1.2*t),
        0.6*np.sin(2*np.pi*3.6*t + 0.3),
        0.45*(1 + 0.2*np.sin(2*np.pi*1.2*t))*np.cos(2*np.pi*42*t)]), 15.0, "colored")

    # 14-16: power / power electronics
    fs, n = 128.0, 4096
    t = np.arange(n) / fs
    add("电力", "低频振荡加工频", "power_lfo_line", fs, np.vstack([
        0.12*np.sin(2*np.pi*0.8*t),
        0.25*np.sin(2*np.pi*6*t + 0.3),
        1.0*np.sin(2*np.pi*60*t + 0.1)]), 18.0, "gaussian")
    fs, n = 1024.0, 4096
    t = np.arange(n) / fs
    add("电力", "电能质量谐波", "power_quality_harmonics", fs, np.vstack([
        1.0*np.sin(2*np.pi*60*t),
        0.20*np.sin(2*np.pi*180*t + 0.2),
        0.12*np.sin(2*np.pi*300*t + 0.5)]), 22.0, "gaussian")
    fs, n = 8192.0, 4096
    t = np.arange(n) / fs
    add("电力电子", "基波纹波开关频率", "power_electronics_switching", fs, np.vstack([
        np.sin(2*np.pi*50*t),
        0.35*np.cos(2*np.pi*100*t + 0.2),
        0.18*np.sin(2*np.pi*2000*t + 0.4)]), 20.0, "gaussian")

    # 17-18: synthetic data-center
    fs, n = 1.0/60.0, 1440
    t = np.arange(n) / fs
    workload = 4.0e6 + 0.55e6*np.sin(2*np.pi*(1/21600.0)*t)
    cooling = 0.35e6*np.cos(2*np.pi*(1/1800.0)*t + 0.25)
    fast = 0.18e6*np.sin(2*np.pi*(1/300.0)*t + 0.5)
    add("数据中心", "多时间尺度功率", "datacenter_multiscale_power", fs,
        np.vstack([workload, cooling, fast]), 25.0, "gaussian")
    slow = 3.5e6 + 0.45e6*np.sin(2*np.pi*(1/28800.0)*t)
    medium = 0.30e6*(1 + 0.35*np.sin(2*np.pi*(1/14400.0)*t))*np.sin(2*np.pi*(1/2400.0)*t)
    fast = 0.16e6*chirp(t, f0=1/900.0, f1=1/300.0, t1=t[-1], method="linear")
    add("数据中心", "非平稳工作负载功率", "datacenter_nonstationary_workload", fs,
        np.vstack([slow, medium, fast]), 22.0, "colored")

    # 19-20: structural / seismic
    fs, n = 256.0, 4096
    t = np.arange(n) / fs
    add("结构工程", "三阶衰减模态", "structural_damped_modes", fs, np.vstack([
        1.0*np.exp(-0.18*t)*np.sin(2*np.pi*8*t),
        0.8*np.exp(-0.28*t)*np.sin(2*np.pi*22*t + 0.2),
        0.55*np.exp(-0.42*t)*np.sin(2*np.pi*48*t + 0.5)]), 20.0, "gaussian")
    fs, n = 100.0, 4096
    t = np.arange(n) / fs
    g1 = np.exp(-0.5*((t - 10)/1.8)**2)
    g2 = np.exp(-0.5*((t - 22)/2.3)**2)
    g3 = np.exp(-0.5*((t - 31)/3.0)**2)
    add("地震", "多波包地震样信号", "seismic_wave_packets", fs, np.vstack([
        g1*np.sin(2*np.pi*4*t),
        0.8*g2*np.sin(2*np.pi*9*t + 0.3),
        0.55*g3*np.cos(2*np.pi*16*t + 0.4)]), 12.0, "colored")

    # 21-22: radar / acoustics
    fs, n = 512.0, 4096
    t = np.arange(n) / fs
    add("雷达通信", "LFM加1Hz双干扰", "radar_lfm_1Hz_interference", fs, np.vstack([
        chirp(t, f0=30, f1=90, t1=t[-1], method="linear"),
        0.55*np.sin(2*np.pi*120*t + 0.1),
        0.45*np.cos(2*np.pi*121*t + 0.6)]), 18.0, "gaussian")
    fs, n = 4096.0, 8192
    t = np.arange(n) / fs
    add("声学", "440_441Hz拍频", "acoustic_440_441_beating", fs, np.vstack([
        np.sin(2*np.pi*440*t),
        0.9*np.cos(2*np.pi*441*t + 0.2),
        0.5*np.sin(2*np.pi*880*t + 0.5)]), 25.0, "gaussian")

    # 23-25: biomedical / ocean / robotics
    fs, n = 50.0, 4096
    t = np.arange(n) / fs
    add("生理", "呼吸脉搏谐波", "physiology_respiration_pulse", fs, np.vstack([
        0.7*np.sin(2*np.pi*0.25*t),
        np.sin(2*np.pi*1.2*t + 0.15*np.sin(2*np.pi*0.1*t)),
        0.25*np.sin(2*np.pi*2.4*t + 0.4)]), 20.0, "gaussian")
    fs, n = 10.0, 4096
    t = np.arange(n) / fs
    add("海洋", "涌浪风浪短波", "ocean_swell_wind_shortwave", fs, np.vstack([
        np.sin(2*np.pi*0.10*t),
        0.65*np.sin(2*np.pi*0.28*t + 0.4),
        0.35*np.cos(2*np.pi*0.75*t + 0.2)]), 18.0, "colored")
    fs, n = 512.0, 4096
    t = np.arange(n) / fs
    add("机器人控制", "伺服共振颤振", "robot_servo_resonance_chatter", fs, np.vstack([
        0.9*np.sin(2*np.pi*2*t),
        0.55*np.sin(2*np.pi*32*t + 0.2),
        0.35*(1 + 0.3*np.cos(2*np.pi*2*t))*np.cos(2*np.pi*85*t)]), 18.0, "impulsive")
    assert len(cases) == 25
    return cases


def abs_corr(a, b):
    a = np.asarray(a, float) - np.mean(a)
    b = np.asarray(b, float) - np.mean(b)
    return abs(float(np.dot(a, b) / ((np.linalg.norm(a)+EPS)*(np.linalg.norm(b)+EPS))))


def matched_metrics(truth, modes):
    truth = np.asarray(truth, float)
    modes = np.asarray(modes, float)
    nt, ne = truth.shape[0], len(modes)
    C = np.zeros((nt, ne), float)
    for i in range(nt):
        for j in range(ne):
            C[i, j] = abs_corr(truth[i], modes[j])
    corr = np.zeros(nt)
    nrmse = np.ones(nt)
    matched = np.full(nt, -1, int)
    if ne:
        rr, cc = linear_sum_assignment(-C)
        for i, j in zip(rr, cc):
            matched[i] = j
            corr[i] = C[i, j]
            y = modes[j].copy()
            if np.dot(truth[i], y) < 0:
                y = -y
            nrmse[i] = np.linalg.norm(truth[i]-y) / (np.linalg.norm(truth[i])+EPS)
    clean = np.sum(truth, axis=0)
    rec = np.sum(modes, axis=0) if ne else np.zeros_like(clean)
    rec_nrmse = np.linalg.norm(clean-rec) / (np.linalg.norm(clean)+EPS)
    return dict(mean_truth_corr=float(np.mean(corr)), min_truth_corr=float(np.min(corr)),
                mean_component_NRMSE=float(np.mean(nrmse)),
                clean_reconstruction_NRMSE=float(rec_nrmse),
                matched_mode_indices=";".join(map(str, matched.tolist())))


def dominant_frequency(y, fs):
    y=np.asarray(y,float)
    p=np.abs(np.fft.rfft(y-np.mean(y)))**2
    f=np.fft.rfftfreq(len(y),d=1.0/fs)
    if len(p)<=1: return 0.0
    return float(f[int(np.argmax(p[1:])+1)])


def center_frequency_mae(truth,modes,fs):
    truth=np.asarray(truth,float); modes=np.asarray(modes,float)
    if len(modes)==0: return float('nan')
    C=np.zeros((len(truth),len(modes)))
    for i in range(len(truth)):
        for j in range(len(modes)): C[i,j]=abs_corr(truth[i],modes[j])
    rr,cc=linear_sum_assignment(-C)
    errs=[]
    for i,j in zip(rr,cc): errs.append(abs(dominant_frequency(truth[i],fs)-dominant_frequency(modes[j],fs)))
    return float(np.mean(errs)) if errs else float('nan')



def stvmd_paper_scenarios(seed=20250924):
    """Single-channel synthetic environments from Jia et al., STVMD.

    Paper settings used here:
      - Fs = 128 Hz for the synthetic examples.
      - stationary Eq. (39): 20 Hz + 0.5*28 Hz.
      - non-stationary Eq. (41): seq=[2,5,0,6,3,1,4,7].
      - non-stationary Eq. (42): two polynomial-phase components.
      - non-stationary Eq. (43): two sinusoidally varying-frequency components.
      - the final three cases use a mild stress variant: the second component is strengthened and the additive white-noise coefficient is 0.22.

    Signal 1 and signal 3 use 8 s so the eight seq intervals / slow modulation
    are fully represented. Signal 2 uses 1 s to keep its instantaneous
    frequencies within the 128-Hz sampling Nyquist interval.
    """
    rng=np.random.default_rng(seed)
    fs=128.0
    cases=[]

    # STVMD Eq. (39): stationary validation, two physical components.
    N=256
    t=np.arange(N,dtype=float)/fs
    truth=np.vstack([
        np.sin(2*np.pi*20.0*t),
        0.5*np.sin(2*np.pi*28.0*t),
    ])
    cases.append(dict(
        domain='STVMD论文',scenario='稳态20Hz_28Hz',slug='stvmd_stationary_20_28',
        fs=fs,truth=truth,input_signal=truth.sum(axis=0),noise_type='none',
        source='STVMD Eq.(39)',stvmd_window=64
    ))

    # STVMD Eq. (41): piecewise jump frequency, 8 one-second segments.
    N=1024
    t=np.arange(N,dtype=float)/fs
    seq=np.asarray([2,5,0,6,3,1,4,7],float)
    idx=np.minimum(np.floor(t).astype(int),len(seq)-1)
    w=13.0+seq[idx]
    truth=np.vstack([
        np.sin(2*np.pi*w*t),
        1.2*np.sin(2*np.pi*2.0*w*t),
    ])
    x=truth.sum(axis=0)+0.22*rng.standard_normal(N)
    cases.append(dict(
        domain='STVMD论文',scenario='非平稳跳频信号1',slug='stvmd_nonstationary_signal1',
        fs=fs,truth=truth,input_signal=x,noise_type='white_0p22',
        source='STVMD Eq.(41) modified stress variant',stvmd_window=64
    ))

    # STVMD Eq. (42): polynomial phase. Duration 1 s avoids aliasing at Fs=128.
    N=128
    t=np.arange(N,dtype=float)/fs
    truth=np.vstack([
        np.sin(2*np.pi*(20.0*t+10.0)*t),
        1.0*np.sin(2*np.pi*(20.0*t+20.0)*t),
    ])
    x=truth.sum(axis=0)+0.22*rng.standard_normal(N)
    cases.append(dict(
        domain='STVMD论文',scenario='非平稳多项式相位信号2',slug='stvmd_nonstationary_signal2',
        fs=fs,truth=truth,input_signal=x,noise_type='white_0p22',
        source='STVMD Eq.(42) modified stress variant',stvmd_window=64
    ))

    # STVMD Eq. (43): sinusoidally varying frequency, 8 s.
    N=1024
    t=np.arange(N,dtype=float)/fs
    truth=np.vstack([
        np.sin(2*np.pi*(2.0*np.sin(2*np.pi*0.25*t)+10.0)*t),
        1.0*np.sin(2*np.pi*(1.5*np.cos(2*np.pi*0.25*t)+40.0)*t),
    ])
    x=truth.sum(axis=0)+0.22*rng.standard_normal(N)
    cases.append(dict(
        domain='STVMD论文',scenario='非平稳正弦调频信号3',slug='stvmd_nonstationary_signal3',
        fs=fs,truth=truth,input_signal=x,noise_type='white_0p22',
        source='STVMD Eq.(43) modified stress variant',stvmd_window=64
    ))
    return cases


def all_benchmark_cases():
    """All 63 cases in the revised, contiguous execution order.

    Positions 1-3: original cases 3, 4, 6 (no signal changes).
    Positions 4-26: remaining original cases 1-26 in original relative order.
    Positions 27-60: all 34 added scenarios, in their original relative order.
    Positions 61-63: the original three STVMD nonstationary cases.

    Original case waveforms and random seeds are generated BEFORE reordering,
    preserving all 29 original numerical signals exactly.
    """
    from benchmark_extra34 import extra_34_scenarios
    original=[]
    for i,c in enumerate(scenario_library(),1):
        cc=dict(c)
        truth=cc['truth']
        cc['input_signal']=add_noise(
            truth.sum(axis=0),cc['snr'],91000+i-1,cc['noise_type']
        )
        cc['source']='existing_25_scenario_library'
        cc['stvmd_window']=64
        original.append(cc)
    paper = stvmd_paper_scenarios()
    original.append(paper[0])  # The existing case 26: stationary STVMD Eq. (39).
    assert len(original)==26
    priority=(3,4,6)
    order=priority+tuple(i for i in range(1,27) if i not in priority)
    out=[original[i-1] for i in order]
    out.extend(extra_34_scenarios(add_noise))
    out.extend(paper[1:])
    assert len(out)==63
    return out
