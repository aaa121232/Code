# -*- coding: utf-8 -*-
"""Run SGVMD and display per-scenario performance without writing any files."""
from __future__ import annotations
import time
import numpy as np

from benchmark_scenarios import all_benchmark_cases, matched_metrics, center_frequency_mae
from sgvmd import run_sgvmd

def run_cases(cases, start_case):
    rows = []
    for case_idx, case in enumerate(cases, start_case):
        x = np.asarray(case["input_signal"], dtype=float)
        truth = np.asarray(case["truth"], dtype=float)
        fs = float(case["fs"])
        true_k = int(truth.shape[0])
        info = {}
        error = ""
        start = time.perf_counter()
        try:
            modes, info = run_sgvmd(x, fs)
            elapsed = time.perf_counter() - start
            modes = np.asarray(modes, dtype=float)
            if modes.ndim == 1:
                modes = modes[None, :]
            length = min(len(x), modes.shape[1])
            modes = modes[:, :length]
            truth_eval = truth[:, :length]
            met = matched_metrics(truth_eval, modes)
            cf = center_frequency_mae(truth_eval, modes, fs)
            out_k = int(len(modes))
            auto_ok = float(out_k == true_k)
            iterations = info.get("vmd", {}).get("iterations", "")
        except Exception as exc:
            elapsed = time.perf_counter() - start
            met = {
                "mean_truth_corr": np.nan, "min_truth_corr": np.nan,
                "mean_component_NRMSE": np.nan,
                "clean_reconstruction_NRMSE": np.nan,
                "matched_mode_indices": "",
            }
            cf = np.nan
            out_k = 0
            auto_ok = np.nan
            iterations = ""
            error = f"{type(exc).__name__}: {exc}"

        centers = ""
        if not error:
            for key in ("candidate_centers_Hz", "center_frequencies_Hz"):
                if key in info:
                    centers = ";".join(f"{v:.9g}" for v in np.asarray(info[key], float).ravel())
                    break
        rows.append({
            "case": case_idx,
            "domain": case["domain"],
            "scenario": case["scenario"],
            "slug": case["slug"],
            "Fs_Hz": fs,
            "N": len(x),
            "algorithm": "SGVMD",
            "K_source": "automatic",
            "true_K": true_k,
            "output_mode_count": out_k,
            "automatic_K_correct": auto_ok,
            "mean_truth_corr": met["mean_truth_corr"],
            "min_truth_corr": met["min_truth_corr"],
            "mean_component_NRMSE": met["mean_component_NRMSE"],
            "clean_reconstruction_NRMSE": met["clean_reconstruction_NRMSE"],
            "center_frequency_MAE_Hz": cf,
            "runtime_s": elapsed,
            "iterations": iterations,
            "routes": ";".join(info.get("routes", [])) if not error else "",
            "center_frequencies_Hz": centers,
            "matched_mode_indices": met["matched_mode_indices"],
            "error": error,
        })
        print(f"[{case_idx:02d}] SGVMD {case['slug']} | K={out_k}/{true_k} | Corr={met['mean_truth_corr']:.6f} | NRMSE={met['mean_component_NRMSE']:.6f} | {elapsed:.4f}s" + (f" | ERROR {error}" if error else ""), flush=True)

    return rows


def main():
    cases = all_benchmark_cases()[:60]
    if len(cases) != 60:
        raise RuntimeError(f"Expected 60 cases, got {len(cases)}")
    run_cases(cases, 1)


if __name__ == "__main__":
    main()
