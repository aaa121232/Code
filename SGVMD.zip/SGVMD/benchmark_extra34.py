# -*- coding: utf-8 -*-
"""34 additional deterministic application-motivated synthetic cases.

The benchmark includes genuinely distinct narrowband use cases and supplementary
nonstationary cases. The number of physical components is defined by the
number of source waveforms in each scene, independently of decomposition output.
"""
from __future__ import annotations
import numpy as np
from scipy.signal import chirp

# domain, scenario, slug, fs, center frequency, sideband spacing, lower/upper amplitude,
# noise SNR, noise model, physical class
# EEG-alpha spacing increases from 1 Hz to 2 Hz; no algorithm changes.
# Three nonstationary simulations use modestly reduced chirp sweep/modulation depth
# to obtain distinct, reproducible source-mode counts (details in README.md).
TRIPLE_CASES = [
 ('电机','感应电机转差边带','induction_motor_slip_sidebands',1024,50,2,.18,.16,20,'gaussian','tones'),
 ('电网','工频邻近间谐波','power_grid_interharmonics',1024,60,2,.30,.23,25,'gaussian','tones'),
 ('电力电子','逆变器窄带扰动','inverter_narrowband_disturbance',512,75,1,.35,.28,25,'gaussian','tones'),
 ('旋转机械','转子不平衡频率簇','rotor_unbalance_cluster',512,42,1,.45,.35,25,'gaussian','tones'),
 ('滚动轴承','轴承载频边带','bearing_carrier_sidebands',1024,100,2,.30,.25,25,'gaussian','tones'),
 ('风电','风机多阶近频振动','wind_turbine_close_orders',512,24,1,.35,.30,25,'gaussian','tones'),
 ('流体机械','离心泵叶频扰动','centrifugal_pump_blade_sidebands',512,35,2,.25,.20,25,'gaussian','tones'),
 ('精密制造','数控机床颤振频带','cnc_chatter_triplet',1024,95,4,.20,.18,25,'gaussian','tones'),
 ('精密制造','主轴偏心窄带振动','spindle_eccentric_triplet',1024,80,2,.22,.25,25,'gaussian','tones'),
 ('轨道交通','列车车轮周期扰动','rail_wheel_triplet',512,50,2,.30,.28,25,'gaussian','tones'),
 ('新能源汽车','驱动电机故障频簇','ev_motor_sidebands',1024,90,3,.25,.22,25,'gaussian','tones'),
 ('储能系统','电池变流器邻频纹波','battery_converter_close_ripple',512,22,1,.35,.30,25,'gaussian','tones'),
 ('输配电','变压器磁致振动边带','transformer_vibration_triplet',1024,55,2,.30,.25,25,'gaussian','tones'),
 ('声学','近频声源拍频','acoustic_close_beating_sources',512,100,1,.55,.50,25,'gaussian','tones'),
 ('水声','主动声纳多普勒边带','sonar_doppler_triplet',512,40,1,.30,.30,25,'gaussian','tones'),
 ('雷达','连续波雷达微多普勒','radar_cw_micro_doppler',1024,100,2,.35,.35,25,'gaussian','tones'),
 ('无线通信','通信载波频偏干扰','radio_carrier_adjacent_interference',1024,90,1,.40,.30,25,'gaussian','tones'),
 ('无损检测','超声检测反射频带','ultrasound_reflection_triplet',131072,30000,200,.40,.25,25,'gaussian','tones'),
 ('生物医学','脉搏节律邻频合成','biomedical_coupled_oscillations',50,1.2,.1,.30,.25,25,'gaussian','tones'),
 ('脑电','脑电Alpha邻频振荡','eeg_alpha_close_oscillations',256,10,2,.35,.30,25,'gaussian','tones'),
 ('呼吸生理','呼吸邻近节律','respiration_close_rhythms',32,.30,.04,.30,.25,25,'gaussian','tones'),
 ('结构监测','桥梁相近固有频率','bridge_close_eigenfrequencies',512,20,1,.35,.30,25,'gaussian','tones'),
 ('海洋工程','三组近频波浪','ocean_close_wave_groups',10,.18,.02,.35,.25,25,'gaussian','tones'),
 ('数据中心','数据中心邻近功率周期','datacenter_close_workload_periods',1/300,1/300*50/512,1/300*1/512,.35,.30,25,'gaussian','tones'),
 ('航空发动机','航空转子细密阶次边带','aviation_rotor_close_orders',1024,65,2,.25,.20,25,'gaussian','tones'),
 ('智慧农业','灌溉泵相邻工作频率','agricultural_irrigation_pump',512,32,1,.30,.22,25,'gaussian','tones'),
 ('光电生理','可穿戴脉搏波邻频','wearable_ppg_close_rhythms',50,1.2,.1,.30,.25,25,'gaussian','tones'),
 ('天文观测','恒星多周期振荡','stellar_close_oscillation_modes',.05,.0012,.0001,.30,.23,25,'gaussian','tones'),
 ('楼宇暖通','暖通设备近频循环','hvac_close_cycle_frequencies',.05,.005,.0001,.33,.25,25,'gaussian','tones'),
]

# Five additional challenging waveform cases complementing the 29 triplets.
# All 34 new cases are now part of the front-60 SGVMD/SVMD/VMD benchmark.
EXTRA_STRESS_CASES = [
 ('航空','双转子加速穿越共振','aerospace_rotor_speed_ramp','multi_chirp',512,2048,16),
 ('地震','频散地震波包','seismic_dispersion_packets','wavepacket',256,2048,12),
 ('海洋','风浪调幅与慢变涌浪','ocean_am_and_swell','am_swell',16,2048,16),
 ('机器人','伺服驱动瞬态扰动','robot_servo_transient_bursts','transient',512,2048,18),
 ('数据中心','突发工作负载与周期功耗','datacenter_bursty_workload','burst_workload',1/60,2048,20),
]

def extra_34_scenarios(add_noise):
    """Construct 34 reproducible simulated records, 3 physical sources each."""
    cases=[]
    for j,(domain,scenario,slug,fs,fc,df,a,b,snr,noise,shape) in enumerate(TRIPLE_CASES):
        n=4096
        t=np.arange(n,dtype=float)/fs
        # Source components are defined before the noise, not inferred from model output.
        truth=np.vstack((
           np.sin(2*np.pi*fc*t + .08),
           a*np.sin(2*np.pi*(fc-df)*t + .2),
           b*np.cos(2*np.pi*(fc+df)*t + .5),
        ))
        x=add_noise(truth.sum(axis=0),snr,35000+j,noise)
        cases.append(dict(domain=domain,scenario=scenario,slug=slug,fs=float(fs),truth=truth,
            input_signal=x,snr=float(snr),noise_type=noise,source='additional_narrowband_triplet',stvmd_window=64))
    for j,(domain,scenario,slug,kind,fs,n,snr) in enumerate(EXTRA_STRESS_CASES):
        t=np.arange(n,dtype=float)/fs
        T=(n-1)/fs
        tn=t/max(T,1e-12)
        if kind=='multi_chirp':
            truth=np.vstack((chirp(t,f0=20,f1=30,t1=T,method='linear'),.7*chirp(t,f0=72,f1=82,t1=T,method='linear'),.4*np.sin(2*np.pi*120*t)))
        elif kind=='am':
            truth=np.vstack(((1+.25*np.sin(2*np.pi*.8*t))*np.sin(2*np.pi*18*t),.7*np.sin(2*np.pi*41*t),.45*np.cos(2*np.pi*75*t)))
        elif kind=='bursts':
            env=.15+.85*(np.sin(2*np.pi*.14*t)>0).astype(float)
            truth=np.vstack((env*np.sin(2*np.pi*2*t),.7*np.sin(2*np.pi*6*t),.45*np.cos(2*np.pi*13*t)))
        elif kind=='wavepacket':
            truth=np.vstack((np.exp(-.5*((tn-.25)/.08)**2)*np.sin(2*np.pi*12*t),.7*np.exp(-.5*((tn-.55)/.10)**2)*np.sin(2*np.pi*27*t),.5*np.exp(-.5*((tn-.75)/.12)**2)*np.cos(2*np.pi*47*t)))
        elif kind=='chirp':
            truth=np.vstack((chirp(t,15,65,T,'linear'),.65*np.sin(2*np.pi*90*t),.4*np.cos(2*np.pi*125*t)))
        elif kind=='fm':
            truth=np.vstack((np.sin(2*np.pi*(.18*t+.03*np.sin(.18*t))),.65*np.sin(2*np.pi*.42*t),.3*np.cos(2*np.pi*1.3*t)))
        elif kind=='am_swell':
            truth=np.vstack((np.sin(2*np.pi*.13*t),.7*(1+.15*np.sin(2*np.pi*.018*t))*np.sin(2*np.pi*.37*t),.4*np.cos(2*np.pi*1.2*t)))
        elif kind=='transient':
            env=np.exp(-.5*((tn-.58)/.055)**2)
            truth=np.vstack((.8*np.sin(2*np.pi*8*t),.6*np.sin(2*np.pi*35*t),env*np.cos(2*np.pi*115*t)))
        elif kind=='damped':
            truth=np.vstack((np.exp(-2*tn)*np.sin(2*np.pi*20*t),.7*np.exp(-3*tn)*np.sin(2*np.pi*55*t),.5*np.exp(-4*tn)*np.cos(2*np.pi*95*t)))
        elif kind=='burst_workload':
            truth=np.vstack(((1+.15*np.sin(2*np.pi*(1/(4*3600))*t))*np.sin(2*np.pi*(1/3600)*t),
                .6*np.sin(2*np.pi*(1/600)*t),
                .35*(.3+.7*(np.sin(2*np.pi*(1/(2*3600))*t)>0))*np.sin(2*np.pi*(1/240)*t)))
        else: raise ValueError(kind)
        x=add_noise(truth.sum(axis=0),snr,45000+j,'gaussian')
        cases.append(dict(domain=domain,scenario=scenario,slug=slug,fs=float(fs),truth=truth,
             input_signal=x,snr=float(snr),noise_type='gaussian',source='additional_nonstationary_stress',stvmd_window=64))
    assert len(cases)==34
    return cases
