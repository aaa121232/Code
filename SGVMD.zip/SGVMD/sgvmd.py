# -*- coding: utf-8 -*-
"""SGVMD: structure-guided variational mode decomposition.

This file implements the SGVMD pipeline described in the accompanying manuscript:
Hankel structural representation, candidate-mode identification, adaptive parameter
mapping, H/S/V routing, selective variational reconstruction, and final global
least-squares amplitude calibration.
Public input: measured real signal ``x`` and sampling frequency ``fs``.
The mode count K, candidate centers, bandwidths, and VMD penalties are inferred
from the signal and are not supplied to ``run_sgvmd``.
"""
from __future__ import annotations

import math
import numpy as np
from scipy.linalg import eigh
from scipy.signal import fftconvolve, find_peaks, stft, istft

EPS = np.finfo(float).eps
PHI_INV_075 = 0.6744897501960817
BROAD_KINDS = frozenset({'broad'})


def haar_noise_scale(x):
    """Haar-difference MAD background-scale estimate used by SGVMD routing."""
    x = np.asarray(x, dtype=float)
    m = len(x) // 2
    z = (x[1:2*m:2] - x[0:2*m:2]) / math.sqrt(2.0)
    z_med = float(np.median(z))
    sigma = float(np.median(np.abs(z - z_med)) / PHI_INV_075)

    # Purely numerical safeguard linked to machine precision, not a user parameter.
    numerical_floor = math.sqrt(EPS * float(np.dot(x, x)) / max(len(x), 1))
    return max(sigma, numerical_floor)


def spectral_moments(Y, fs):
    """
    SGVMD structural descriptor.

    Each structural component is described by:
        peak angular frequency omega_p,
        spectral second central moment b_i^2,
        spectral concentration kappa_i,
        effective frequency uncertainty v_i.

    The key parameter-free uncertainty is

        v_i = (Delta_omega^2)/12 + ((1-kappa_i)/kappa_i) * b_i^2

    Interpretation:
    - a stationary narrowband structure generally yields a small v_i;
    - a broadband or nonstationary structure generally yields a larger v_i.

    The resulting v_i is used as the effective frequency uncertainty in the
    subsequent contiguous structural grouping.
    """
    n = Y.shape[1]
    omega = 2.0 * np.pi * np.fft.rfftfreq(n, d=1.0 / fs)
    delta_omega = 2.0 * np.pi * fs / n
    resolution_variance = (delta_omega ** 2) / 12.0

    peaks = np.empty(len(Y), dtype=float)
    centers = np.empty(len(Y), dtype=float)
    variances = np.empty(len(Y), dtype=float)
    concentrations = np.empty(len(Y), dtype=float)
    effective_variances = np.empty(len(Y), dtype=float)
    energies = np.empty(len(Y), dtype=float)

    for i, y in enumerate(Y):
        p = np.abs(np.fft.rfft(y)) ** 2
        E = float(np.sum(p))
        j = int(np.argmax(p))

        peak = float(omega[j])
        center = float(np.sum(omega * p) / (E + EPS))
        b2 = float(np.sum((omega - center) ** 2 * p) / (E + EPS))
        kappa = float(p[j] / (E + EPS))

        # Numerical floor is linked only to floating-point precision.
        kappa = max(kappa, EPS)
        b2 = max(b2, 0.0)

        v_eff = resolution_variance + ((1.0 - kappa) / kappa) * b2
        v_eff = max(v_eff, EPS)

        peaks[i] = peak
        centers[i] = center
        variances[i] = b2
        concentrations[i] = kappa
        effective_variances[i] = v_eff
        energies[i] = E

    return (
        peaks,
        centers,
        variances,
        concentrations,
        effective_variances,
        energies,
    )


def _partition(centers, variances, n):
    """
    Dynamic-programming structural partition.

    The objective is the sum of the normalized intragroup dispersion costs and
    B*log(N_f), where N_f is the number of one-sided Fourier bins.  This balances
    structural consistency against the number of contiguous groups without an
    additional user-tuned coefficient.
    """
    M = len(centers)
    if M == 1:
        return [[0]], float(math.log(n // 2 + 1))

    order = np.argsort(centers)
    c = np.asarray(centers)[order]
    v = np.maximum(np.asarray(variances)[order], EPS)

    cost = np.zeros((M, M), dtype=float)

    for a in range(M):
        inv_v = 1.0 / v[a:]
        cum_w = np.cumsum(inv_v)
        cum_wc = np.cumsum(c[a:] * inv_v)
        cum_wc2 = np.cumsum(c[a:] ** 2 * inv_v)

        for b in range(a, M):
            j = b - a
            q = cum_wc2[j] - (cum_wc[j] ** 2) / cum_w[j]
            cost[a, b] = max(float(q), 0.0)

    dp = np.full(M + 1, np.inf)
    prev = np.full(M + 1, -1, dtype=int)
    dp[0] = 0.0

    n_frequency_observations = n // 2 + 1
    penalty = math.log(n_frequency_observations)

    for j in range(1, M + 1):
        for i in range(j):
            value = dp[i] + cost[i, j - 1] + penalty
            if value < dp[j]:
                dp[j] = value
                prev[j] = i

    groups = []
    j = M
    while j > 0:
        i = int(prev[j])
        groups.append(order[i:j].tolist())
        j = i

    groups.reverse()
    return groups, float(dp[M])


def _least_squares_lines(x, fs, freqs):
    """Joint least-squares real line components for close-frequency splitting."""
    x = np.asarray(x, dtype=float)
    freqs = np.asarray(freqs, dtype=float)

    n = len(x)
    if len(freqs) == 0:
        return np.empty((0, n), dtype=float)

    t = np.arange(n, dtype=float) / fs
    df = fs / n

    cols = []
    descriptors = []

    for f in freqs:
        if abs(f) <= df / 2.0:
            cols.append(np.ones(n))
            descriptors.append(("zero", len(cols) - 1))
        else:
            cols.append(np.cos(2.0 * np.pi * f * t))
            cols.append(np.sin(2.0 * np.pi * f * t))
            descriptors.append(("pair", len(cols) - 2))

    X = np.column_stack(cols)
    beta = np.linalg.lstsq(X, x, rcond=None)[0]

    waves = []
    for kind, j in descriptors:
        if kind == "zero":
            waves.append(X[:, j] * beta[j])
        else:
            waves.append(X[:, j] * beta[j] + X[:, j + 1] * beta[j + 1])

    return np.asarray(waves, dtype=float)


def _candidate_from_wave(wave, fs, kind, center_override=None):
    wave = np.asarray(wave, dtype=float)
    n = len(wave)
    f = np.fft.rfftfreq(n, d=1.0 / fs)
    p = np.abs(np.fft.rfft(wave)) ** 2
    E = float(np.sum(p))

    if center_override is None:
        center = float(np.sum(f * p) / (E + EPS))
    else:
        center = float(center_override)

    df = fs / n
    B2 = float(
        np.sum((f - center) ** 2 * p) / (E + EPS)
        + df**2 / 12.0
    )

    return {
        "center": center,
        "wave": wave.copy(),
        "rawB": math.sqrt(max(B2, EPS)),
        "kind": str(kind),
    }


def _spectral_peaks(x, fs):
    """Single full-record spectral evidence detector with parabolic bin refinement."""
    x=np.asarray(x,float); n=len(x)
    P=np.abs(np.fft.rfft(x))**2; f=np.fft.rfftfreq(n,d=1.0/fs); nf=len(P)
    W=max(3,int(math.ceil(math.sqrt(nf))))
    peaks,_=find_peaks(P); plist=list(peaks)
    if nf>1 and P[0]>P[1]: plist=[0]+plist
    if nf>1 and P[-1]>P[-2]: plist=plist+[nf-1]
    out=[]
    for p in plist:
        # Use at most W samples exactly as defined in Eq. (12). For an even W,
        # the window is deterministically left-biased by one sample; near a
        # spectrum edge it is shifted, not enlarged.
        left_count=(W-1)//2
        lo=p-left_count
        hi=lo+W
        if lo<0:
            hi=min(nf,hi-lo); lo=0
        if hi>nf:
            lo=max(0,lo-(hi-nf)); hi=nf
        vals=P[lo:hi]
        mu=float(np.median(vals))/math.log(2.0)+EPS
        gain=float(P[p]/mu-3.0*math.log(n))
        if gain<=0.0: continue
        refined=float(f[p])
        if 0<p<len(P)-1:
            y1=math.log(P[p-1]+EPS); y2=math.log(P[p]+EPS); y3=math.log(P[p+1]+EPS)
            den=y1-2.0*y2+y3
            if den!=0.0:
                delta=0.5*(y1-y3)/den
                if abs(delta)<=0.5: refined=(p+delta)*fs/n
        out.append((int(p),float(refined),float(gain)))
    return out


def _independent_line_fit(x, fs, freqs):
    x = np.asarray(x, dtype=float)
    freqs = np.asarray(freqs, dtype=float)
    t = np.arange(len(x), dtype=float) / fs

    cols = []

    for f0 in freqs:
        if abs(f0) <= EPS:
            cols.append(np.ones(len(x)))
        else:
            cols.append(np.cos(2.0 * np.pi * f0 * t))
            cols.append(np.sin(2.0 * np.pi * f0 * t))

    H = np.column_stack(cols)
    coef = np.linalg.lstsq(H, x, rcond=None)[0]
    y = H @ coef
    rss = float(np.sum((x - y) ** 2))

    return y, rss, coef


def _ridge_linear_bic_gain(y, fs):
    """
    Time-frequency ridge model:
        constant ridge  vs.  linear ridge
    Positive BIC gain means a coherent moving ridge (chirp-like mode) is
    preferred.
    """
    y = np.asarray(y, dtype=float)
    n = len(y)

    L = max(16, min(n, int(math.ceil(math.sqrt(n)))))

    _, _, Z = stft(
        y,
        fs=fs,
        nperseg=L,
        noverlap=L // 2,
        boundary=None,
        padded=False,
    )

    P = np.abs(Z) ** 2
    E = np.sum(P, axis=0) + EPS
    ridge = np.argmax(P, axis=0).astype(float)

    T = len(ridge)

    if T < 3:
        return -np.inf

    tt = np.arange(T, dtype=float)
    H = np.column_stack([np.ones(T), tt])

    W = np.sqrt(E)
    beta = np.linalg.lstsq(H * W[:, None], ridge * W, rcond=None)[0]
    pred = H @ beta

    mean_ridge = float(np.sum(E * ridge) / np.sum(E))

    rss_const = float(np.sum(E * (ridge - mean_ridge) ** 2)) + EPS
    rss_line = float(np.sum(E * (ridge - pred) ** 2)) + EPS

    bic_const = T * math.log(rss_const / T) + math.log(T)
    bic_line = T * math.log(rss_line / T) + 2.0 * math.log(T)

    return float(bic_const - bic_line)


def _svht_fast_exact(x):
    x=np.asarray(x,float); n=len(x)
    d=int(math.ceil(math.sqrt(n))); d=max(2,min(d,n-1)); m=n-d+1
    X=np.lib.stride_tricks.sliding_window_view(x,d)
    A=np.empty((d,d),float)
    for ell in range(d):
        z=x[:n-ell]*x[ell:]
        pref=np.empty(len(z)+1,float); pref[0]=0.0; np.cumsum(z,out=pref[1:])
        idx=np.arange(d-ell)
        vals=pref[idx+m]-pref[idx]
        A[idx,idx+ell]=vals
        A[idx+ell,idx]=vals
    vals,Q=eigh(A,check_finite=False)
    order=np.argsort(vals)[::-1]; vals=np.maximum(vals[order],0.0); Q=Q[:,order]
    svals=np.sqrt(vals)
    beta=min(d,m)/max(d,m)
    omega_beta=0.56*beta**3-0.95*beta**2+1.82*beta+1.43
    median_s=float(np.median(svals)); sigma_edge=float(omega_beta*median_s)
    M=max(1,int(np.sum(svals>sigma_edge)))
    Qs=Q[:,:M]; s_keep=svals[:M]
    counts=fftconvolve(np.ones(d),np.ones(m),mode='full')
    Y=np.empty((M,n),float)
    for i in range(M):
        score=X@Qs[:,i]
        Y[i]=fftconvolve(Qs[:,i],score,mode='full')/counts
    sigma_background=median_s/math.sqrt(m)
    return Y, {'d':d,'m':m,'M':M,'Q_signal':Qs,'singular_values':s_keep.copy(),
               'sigma_edge':sigma_edge,'sigma_background':float(sigma_background),'omega_beta':float(omega_beta)}


def _variable_projection_vpgn(x,fs,cands,stationary_idx,effective_bandwidth=None):
    """Projected Gauss--Newton variable projection used for SGVMD harmonic refinement.

    The implementation follows the manuscript description:
    - QR projection forms the projected Jacobian direction;
    - each frequency update is constrained to its structure-derived interval Omega_k;
    - an RSS increase triggers successive bisection backtracking;
    - at most ceil(log2(max(N,2))) Gauss--Newton/backtracking iterations are used.
    """
    x=np.asarray(x,float);n=len(x);t=np.arange(n,dtype=float)/fs;K=len(cands);centers=np.asarray([c['center'] for c in cands],float);df=fs/n
    stationary_idx=sorted(set(map(int,stationary_idx)));nuisance_idx=[k for k in range(K) if k not in stationary_idx];f=centers[stationary_idx].copy();bounds=[]
    if effective_bandwidth is not None:
        effective_bandwidth=np.asarray(effective_bandwidth,float)
        if len(effective_bandwidth)!=K:
            raise ValueError('effective_bandwidth must contain one value per candidate')
    for k in stationary_idx:
        if effective_bandwidth is None:
            Dk=float(np.min(np.abs(np.delete(centers,k)-centers[k]))) if K>1 else fs/2.0
            Bk=max(df/math.sqrt(12.0),min(float(cands[k]['rawB']),Dk/2.0))
        else:
            Bk=float(effective_bandwidth[k])
        bounds.append((max(0.0,centers[k]-Bk),min(fs/2.0,centers[k]+Bk)))
    def solve(freq):
        cols=[];loc={}
        for k,ff in zip(stationary_idx,freq):
            a=len(cols);cols += [np.cos(2*np.pi*ff*t),np.sin(2*np.pi*ff*t)];loc[k]=(a,a+1)
        for k in nuisance_idx:
            a=len(cols);cols.append(np.asarray(cands[k]['wave'],float));loc[k]=(a,None)
        A=np.column_stack(cols);Q,_=np.linalg.qr(A,mode='reduced');coef=np.linalg.lstsq(A,x,rcond=None)[0];r=x-A@coef
        return A,Q,coef,loc,r
    if len(stationary_idx):
        maxit=int(math.ceil(math.log2(max(n,2))))
        for it in range(maxit):
            A,Q,coef,loc,r=solve(f);J=[]
            for j,k in enumerate(stationary_idx):
                a,b=loc[k];ff=f[j];d=2*np.pi*t*(-coef[a]*np.sin(2*np.pi*ff*t)+coef[b]*np.cos(2*np.pi*ff*t));d=d-Q@(Q.T@d);J.append(d)
            J=np.column_stack(J);delta=np.linalg.lstsq(J,r,rcond=None)[0];new=f+delta
            for j,(lo,hi) in enumerate(bounds):new[j]=np.clip(new[j],lo,hi)
            if np.max(np.abs(new-f))<=math.sqrt(EPS)*max(fs,1.0):f=new;break
            _,_,_,_,rnew=solve(new)
            if np.dot(rnew,rnew)>np.dot(r,r):
                step=new-f
                accepted=False
                for _ in range(maxit):
                    step*=0.5;trial=f+step;_,_,_,_,rt=solve(trial)
                    if np.dot(rt,rt)<=np.dot(r,r):new=trial;accepted=True;break
                if not accepted:new=f
            f=new
    A,Q,coef,loc,r=solve(f);waves={}
    for k,(a,b) in loc.items():waves[k]=coef[a]*A[:,a] if b is None else coef[a]*A[:,a]+coef[b]*A[:,b]
    return waves,f,float(np.dot(r,r))


def _classical_vmd_three_equations(x,fs,candidates,alpha,tau=None,maxiter=None):
    """Classical VMD using the structure-derived alpha map."""
    x=np.asarray(x,float); n=len(x); K=len(candidates)
    alpha=np.asarray(alpha,float)
    if K==0:
        return np.empty((0,n)),{
            'iterations':0,'tau':0.0,'alpha':np.array([]),
            'final_centers_rad_s':np.array([]),'converged':True}
    if len(alpha)!=K:
        raise ValueError('alpha must contain one value per V-mode candidate')
    if tau is None: tau=1.0/math.sqrt(max(n,1))
    if maxiter is None: maxiter=max(64,int(math.ceil(math.sqrt(n))*16))
    centers=np.asarray([c['center'] for c in candidates],float)
    omega_k=2*np.pi*centers.copy()
    pad=min(n-1,int(math.ceil(math.sqrt(n))))
    xm=np.concatenate([x[:pad][::-1],x,x[-pad:][::-1]])
    T=len(xm); omega=2*np.pi*np.fft.fftshift(np.fft.fftfreq(T,d=1.0/fs)); pos=omega>=0
    fhat=np.fft.fftshift(np.fft.fft(xm)); fplus=fhat.copy(); fplus[~pos]=0.0
    u=np.zeros((K,T),complex)
    for k,c in enumerate(candidates):
        w=np.asarray(c['wave'],float); wm=np.concatenate([w[:pad][::-1],w,w[-pad:][::-1]])
        wh=np.fft.fftshift(np.fft.fft(wm)); wh[~pos]=0.0; u[k]=wh
    lam=np.zeros(T,complex); stop=math.sqrt(EPS); converged=False
    for it in range(maxiter):
        old=u.copy(); total_old=np.sum(old,axis=0); old_before=np.zeros(T,complex); new_before=np.zeros(T,complex)
        for k in range(K):
            old_future=total_old-old_before-old[k]; others=new_before+old_future
            u[k]=(fplus-others+lam/2.0)/(1.0+2.0*alpha[k]*(omega-omega_k[k])**2)
            power=np.abs(u[k,pos])**2
            omega_k[k]=float(np.sum(omega[pos]*power)/(np.sum(power)+EPS))
            old_before+=old[k]; new_before+=u[k]
        lam=lam+tau*(fplus-np.sum(u,axis=0))
        rel=float(np.sum(np.abs(u-old)**2)/(np.sum(np.abs(old)**2)+EPS))
        if rel<=stop:
            converged=True; break
    modes=np.empty((K,n),float)
    for k in range(K):
        tm=2*np.real(np.fft.ifft(np.fft.ifftshift(u[k]))); modes[k]=tm[pad:pad+n]
    return modes,{
        'iterations':it+1,'converged':converged,'tau':tau,
        'alpha':alpha.copy(),'final_centers_rad_s':omega_k}


def _multiridge_split_candidate(candidate,fs):
    """Fallback multi-ridge detection and time-frequency soft partitioning.

    The time-frequency evidence counts significant interior local peaks in each
    frame, estimates the persistent ridge count as the smallest mode of the
    positive frame-wise counts, orders the selected peaks by ascending frequency,
    interpolates missing ridge samples along time, and applies the normalized
    Gaussian soft partition to reconstruct one child candidate per ridge.

    Returns
    -------
    children : list[dict]
        One candidate if q*=1; otherwise q* ridge children.
    diag : dict
        Diagnostic values saved by the benchmark.
    """
    y=np.asarray(candidate['wave'],float)
    n=len(y)

    # Hamming-window STFT on a data-determined window.
    _v=max(2.0*math.sqrt(n),1.0)
    L=max(2,min(n,int(2**math.ceil(math.log2(_v)))))
    noverlap=L//2
    f,tt,Z=stft(
        y,fs=fs,window='hamming',nperseg=L,noverlap=noverlap,nfft=L,
        boundary='even',padded=True
    )
    P=np.abs(Z)**2
    R=len(f)
    T=P.shape[1]

    # Frame-wise significant interior local maxima.  The background power is
    # median_r |Z(r,q)|^2 / log(2), and the threshold is mu_q*log(max(R,2)).
    counts=[]
    significant=[]
    for j in range(T):
        pj=P[:,j]
        mu=float(np.median(pj))/math.log(2.0)+EPS
        theta=mu*math.log(max(R,2))
        pk,_=find_peaks(pj)
        pk=[int(r) for r in pk if pj[r]>theta]
        pk=sorted(pk,key=lambda r:float(pj[r]),reverse=True)
        significant.append(pk)
        counts.append(len(pk))

    # Persistent ridge number = the smallest mode of the positive integer peak counts.
    positive=[q for q in counts if q>=1]
    if not positive:
        return [candidate],{
            'ridge_count':1,'window_length':L,'frame_counts':counts,
            'reason':'no_significant_peak'
        }
    vals,cts=np.unique(np.asarray(positive,int),return_counts=True)
    max_ct=int(np.max(cts))
    q=int(np.min(vals[cts==max_ct]))
    if q<=1:
        return [candidate],{
            'ridge_count':1,'window_length':L,'frame_counts':counts,
            'reason':'single_persistent_ridge'
        }

    # In each frame, keep the q* strongest significant peaks and arrange them
    # in ascending frequency order; interpolate ridge samples along time when a
    # frame contains too few significant peaks.
    ridges=np.full((q,T),np.nan,float)
    for j,pk in enumerate(significant):
        if len(pk)<q:
            continue
        sel=sorted(pk[:q])
        ridges[:,j]=f[sel]

    for ell in range(q):
        good=np.flatnonzero(np.isfinite(ridges[ell]))
        if len(good)==0:
            return [candidate],{
                'ridge_count':1,'window_length':L,'frame_counts':counts,
                'reason':'ridge_track_missing'
            }
        ridges[ell]=np.interp(np.arange(T),good,ridges[ell,good])

    # Apply the manuscript separability condition: adjacent ridge trajectories
    # are accepted only when d_min >= 2*Delta_f_L under the current STFT resolution.
    df_stft=float(fs)/L
    if q>1:
        med_sep=[]
        for ell in range(q-1):
            med_sep.append(float(np.median(ridges[ell+1]-ridges[ell])))
        if min(med_sep) < 2.0*df_stft:
            return [candidate],{
                'ridge_count':1,'window_length':L,'frame_counts':counts,
                'proposed_ridge_count':q,'median_separation_Hz':med_sep,
                'reason':'below_hamming_resolution'
            }

    # Time-frequency soft partition defined by sigma_TF and normalized Gaussian
    # weights.  At the separability boundary sigma_TF -> 0; otherwise the scale
    # is determined directly by Delta_f_L and d_min.
    weights=np.zeros((q,R,T),float)
    df_stft=float(fs)/L
    min_sep=float(min(med_sep)) if q>1 and med_sep else float('inf')
    sigma_soft=0.5*df_stft*max(0.0,1.0-2.0*df_stft/(min_sep+EPS))
    for j in range(T):
        dist=np.abs(f[:,None]-ridges[:,j][None,:])
        if sigma_soft<=math.sqrt(EPS)*max(df_stft,1.0):
            labels=np.argmin(dist,axis=1)
            W=np.zeros_like(dist)
            W[np.arange(R),labels]=1.0
        else:
            logits=-0.5*(dist/sigma_soft)**2
            logits-=np.max(logits,axis=1,keepdims=True)
            W=np.exp(logits)
            W/=np.sum(W,axis=1,keepdims=True)
        weights[:,:,j]=W.T

    children=[]
    recon=np.zeros(n,float)
    for ell in range(q):
        Zell=Z*weights[ell]
        _,wave=istft(
            Zell,fs=fs,window='hamming',nperseg=L,noverlap=noverlap,nfft=L,
            input_onesided=True,boundary=True
        )
        wave=np.asarray(wave,float)
        if len(wave)<n:
            wave=np.pad(wave,(0,n-len(wave)))
        wave=wave[:n]
        recon+=wave
        c2=_candidate_from_wave(
            wave,fs,'ridge',float(np.mean(ridges[ell]))
        )
        c2['multiridge_parent_kind']=candidate.get('kind','')
        c2['ridge_track_Hz']=ridges[ell].copy()
        c2['ridge_window_length']=L
        children.append(c2)

    diag={
        'ridge_count':q,
        'window_length':L,
        'frame_counts':counts,
        'mean_ridge_Hz':[float(np.mean(r)) for r in ridges],
        'median_separation_Hz':[
            float(np.median(ridges[i+1]-ridges[i])) for i in range(q-1)
        ],
        'soft_partition_sigma_Hz':float(sigma_soft),
        'split_reconstruction_NRMSE':float(
            np.linalg.norm(y-recon)/(np.linalg.norm(y)+EPS)
        ),
        'reason':'multi_ridge_split'
    }
    return children,diag


def _effective_bandwidths(cands,fs,n):
    centers=np.asarray([c['center'] for c in cands],float); raw=np.asarray([c['rawB'] for c in cands],float); K=len(cands)
    D=np.full(K,fs/2.0)
    if K>1:
        for k in range(K):
            D[k]=float(np.min(np.abs(np.delete(centers,k)-centers[k])))
    B=np.minimum(raw,D/2.0)
    B=np.maximum(B,fs/n/math.sqrt(12.0)); alpha=1.0/(2.0*np.maximum((2*np.pi*B)**2,EPS))
    return centers,raw,B,D,alpha


def _base_candidates(x, fs):
    """Low-rank structural representation and one information-criterion partition."""
    x = np.asarray(x, float)
    n = len(x)
    Y, structure = _svht_fast_exact(x)
    peak, center, variance, concentration, effective_variance, energy = spectral_moments(Y, fs)
    groups, objective = _partition(peak, effective_variance, n)

    blocks = [
        _candidate_from_wave(np.sum(Y[g], axis=0), fs, 'broad', None)
        for g in groups
    ]

    structure.update({
        'groups': groups,
        'partition_objective': float(objective),
        'structural_peak_rad_s': peak,
        'structural_effective_variance': effective_variance,
    })
    return sorted(blocks, key=lambda c: c['center']), structure


def _reject_diffuse_background(candidates, structure, n):
    """Apply the low-energy diffuse-background rejection to IC coarse blocks."""
    noise_energy = n * structure['sigma_background'] ** 2
    entropy_boundary = math.sqrt(n // 2 + 1)
    kept = []
    for c in candidates:
        wave = np.asarray(c['wave'], float)
        block_energy = float(np.dot(wave, wave))
        P = np.abs(np.fft.rfft(wave)) ** 2
        p = P / (float(np.sum(P)) + EPS)
        nz = p > 0
        effective_bins = math.exp(-float(np.sum(p[nz] * np.log(p[nz]))))
        if block_energy <= noise_energy and effective_bins >= entropy_boundary:
            continue
        kept.append(c)
    structure['noise_energy_proxy'] = float(noise_energy)
    structure['entropy_boundary'] = float(entropy_boundary)
    return kept


def _voronoi_peaks(peak_freqs, left, right, is_last):
    """Return uniquely owned peaks for [left,right), with a closed final interval."""
    if is_last:
        return sorted(float(f) for f in peak_freqs if left <= f <= right)
    return sorted(float(f) for f in peak_freqs if left <= f < right)


def _line_split_stage(x, fs):
    """Assign global significant peaks to coarse blocks and apply G_E sufficiency."""
    x = np.asarray(x, float)
    n = len(x)
    df = fs / n
    blocks, structure = _base_candidates(x, fs)
    blocks = _reject_diffuse_background(blocks, structure, n)

    peak_records = _spectral_peaks(x, fs)
    peak_freqs = np.asarray([r[1] for r in peak_records], float)
    centers = np.asarray([c['center'] for c in blocks], float)
    out = []
    block_meta = []

    for b, c in enumerate(blocks):
        left = 0.0 if b == 0 else 0.5 * (centers[b - 1] + centers[b])
        right = fs / 2.0 if b == len(blocks) - 1 else 0.5 * (centers[b] + centers[b + 1])
        # Voronoi ownership is unique: [left,right) except the final block,
        # whose Nyquist endpoint is included. A midpoint peak therefore belongs
        # deterministically to the higher-center block.
        selected = _voronoi_peaks(peak_freqs, left, right, b == len(blocks) - 1)

        # If the lowest significant frequency lies within Delta_f/2 of zero,
        # retain the coarse block directly as a trend candidate.
        if selected and abs(selected[0]) <= df / 2.0:
            cand = _candidate_from_wave(c['wave'], fs, 'trend', 0.0)
            cand['source_block_index'] = int(b)
            cand['split_from_GE'] = False
            out.append(cand)
            block_meta.append({'left_Hz': left, 'right_Hz': right, 'peaks_Hz': selected, 'G_E': np.nan})
            continue

        # With no significant spectral peak, retain a broad coarse block only when
        # the linear-ridge evidence is positive; otherwise discard it.  If no valid
        # candidate remains after structural processing, _build_candidates applies
        # the whole-signal multi-ridge fallback.
        if not selected:
            ridge_gain = _ridge_linear_bic_gain(c['wave'], fs)
            if c.get('kind') in BROAD_KINDS:
                if ridge_gain > 0.0:
                    cand = _candidate_from_wave(c['wave'], fs, 'ridge', None)
                    cand['source_block_index'] = int(b)
                    cand['split_from_GE'] = False
                    out.append(cand)
            else:
                c = dict(c)
                c['source_block_index'] = int(b)
                c['split_from_GE'] = False
                out.append(c)
            block_meta.append({'left_Hz': left, 'right_Hz': right, 'peaks_Hz': [], 'G_E': np.nan,
                               'ridge_BIC_gain': float(ridge_gain)})
            continue

        # Jointly fit all significant stationary spectral lines to the coarse
        # Hankel block c_b and evaluate the spectral-line splitting sufficiency G_E.
        coarse_wave = np.asarray(c['wave'], float)
        line_fit, line_rss, _ = _independent_line_fit(coarse_wave, fs, selected)
        G_E = float(np.dot(line_fit, line_fit) - line_rss)
        block_meta.append({'left_Hz': left, 'right_Hz': right, 'peaks_Hz': selected, 'G_E': G_E})

        if G_E > 0.0:
            waves = _least_squares_lines(x, fs, selected)
            for f0, wave in zip(selected, waves):
                cand = _candidate_from_wave(wave, fs, 'line', f0)
                cand['source_block_index'] = int(np.argmin(np.abs(centers - float(f0))))
                cand['split_from_GE'] = True
                out.append(cand)
        else:
            ridge_gain = _ridge_linear_bic_gain(c['wave'], fs)
            kind = 'ridge' if ridge_gain > 0.0 else 'broad'
            cand = _candidate_from_wave(
                c['wave'], fs, kind, None if kind == 'ridge' else c['center']
            )
            cand['source_block_index'] = int(b)
            cand['split_from_GE'] = False
            out.append(cand)

    return sorted(out, key=lambda c: c['center']), blocks, structure, peak_freqs, block_meta


def _bic(y, prediction, parameter_count):
    y = np.asarray(y, float)
    prediction = np.asarray(prediction, float)
    n = len(y)
    rss = float(np.sum((y - prediction) ** 2))
    return n * math.log((rss + EPS) / n) + int(parameter_count) * math.log(n)



def _compact_sideband_model(x, fs, freqs):
    """Three-line complex sideband projection used by the blockwise BIC test."""
    x = np.asarray(x, float)
    f_minus, f0, f_plus = sorted(map(float, freqs))
    n = len(x)
    t = np.arange(n, dtype=float) / fs

    H = np.column_stack([
        np.cos(2*np.pi*f_minus*t), np.sin(2*np.pi*f_minus*t),
        np.cos(2*np.pi*f0*t),      np.sin(2*np.pi*f0*t),
        np.cos(2*np.pi*f_plus*t),  np.sin(2*np.pi*f_plus*t),
    ])
    beta = np.linalg.lstsq(H, x, rcond=None)[0]
    C_minus = beta[0] - 1j * beta[1]
    C0 = beta[2] - 1j * beta[3]
    C_plus = beta[4] - 1j * beta[5]
    if abs(C0) <= math.sqrt(EPS):
        raise ValueError('center-line complex amplitude is numerically zero')

    q = 0.5 * (C_plus / C0 + np.conj(C_minus / C0))
    C_minus_hat = C0 * np.conj(q)
    C_plus_hat = C0 * q
    f_mod = 0.5 * (f_plus - f_minus)
    wave = np.real(
        C_minus_hat * np.exp(1j * 2*np.pi*(f0 - f_mod)*t)
        + C0 * np.exp(1j * 2*np.pi*f0*t)
        + C_plus_hat * np.exp(1j * 2*np.pi*(f0 + f_mod)*t)
    )
    gain = float(np.dot(wave, x) / (np.dot(wave, wave) + EPS))
    return gain * wave, float(f0)


def _blockwise_representation_selection(line_candidates, coarse_blocks, x, fs, peak_freqs):
    """Three-line BIC selection; >=4 significant lines keep the coarse block."""
    if not line_candidates:
        return []

    x = np.asarray(x, float)
    centers = np.asarray([c['center'] for c in coarse_blocks], float)
    out = []

    for b, block in enumerate(coarse_blocks):
        sub = sorted(
            [c for c in line_candidates if int(c.get('source_block_index', -1)) == b],
            key=lambda c: c['center'],
        )
        if not sub:
            continue

        left = 0.0 if b == 0 else 0.5 * (centers[b - 1] + centers[b])
        right = fs / 2.0 if b == len(coarse_blocks) - 1 else 0.5 * (centers[b] + centers[b + 1])
        local_peaks = _voronoi_peaks(peak_freqs, left, right, b == len(coarse_blocks) - 1)

        # Apply the compact-sideband or dense-multiline decision only to line
        # candidates produced from this same coarse block by G_E^(c) > 0.
        eligible_lines = all(
            c.get('kind') == 'line' and bool(c.get('split_from_GE', False))
            for c in sub
        )
        if len(sub) < 2 or len(local_peaks) < 2 or not eligible_lines:
            out.extend(sub)
            continue

        if len(local_peaks) == 3:
            # A compact AM triplet requires approximately symmetric sidebands.
            f_minus, f0, f_plus = local_peaks
            if abs(f0 - 0.5 * (f_minus + f_plus)) > fs / (2.0 * len(x)):
                out.extend(sub)
                continue
            try:
                compact_wave, center = _compact_sideband_model(x, fs, local_peaks)
                independent, _, _ = _independent_line_fit(x, fs, local_peaks)
                bic_compact = _bic(x, compact_wave, 4)
                bic_independent = _bic(x, independent, 6)
                if bic_compact < bic_independent:
                    c = _candidate_from_wave(compact_wave, fs, 'modulated', center)
                    c['block_model'] = 'complex_sideband'
                    c['BIC_compact'] = float(bic_compact)
                    c['BIC_independent'] = float(bic_independent)
                    c['source_block_index'] = int(b)
                    c['split_from_GE'] = True
                    out.append(c)
                    continue
            except ValueError:
                pass
            out.extend(sub)
            continue

        if len(local_peaks) >= 4:
            c = _candidate_from_wave(block['wave'], fs, 'dense_multiline', block['center'])
            c['block_model'] = 'dense_multiline'
            c['source_block_index'] = int(b)
            c['split_from_GE'] = True
            out.append(c)
            continue

        # One or two supported lines remain independent.
        out.extend(sub)

    return sorted(out, key=lambda c: c['center'])


def _build_candidates(x, fs):
    """Construct the final candidate set and fix K before H/S/V routing."""
    line_candidates, coarse_blocks, structure, peaks, block_meta = _line_split_stage(x, fs)
    candidates = _blockwise_representation_selection(
        line_candidates, coarse_blocks, x, fs, peaks
    )
    if not candidates:
        candidates = [_candidate_from_wave(x, fs, 'fallback', None)]

    final = []
    events = []
    for idx, c in enumerate(candidates):
        if c.get('kind') == 'fallback':
            children, diag = _multiridge_split_candidate(c, fs)
            diag['parent_index'] = idx
            diag['parent_center_Hz'] = float(c.get('center', np.nan))
            events.append(diag)
            final.extend(children)
        else:
            final.append(c)

    final = sorted(final, key=lambda c: float(c.get('center', 0.0)))
    structure['block_evidence'] = block_meta
    return final, structure, peaks, events


def run_sgvmd(x, fs):
    """Run SGVMD with automatic K, centers, bandwidths and VMD penalties."""
    x = np.asarray(x, float)
    if x.ndim != 1:
        raise ValueError('x must be a one-dimensional real sequence')
    n = len(x)
    if n < 8:
        raise ValueError('SGVMD requires N >= 8 samples')
    if not np.isfinite(fs) or fs <= 0:
        raise ValueError('fs must be a positive finite sampling frequency')
    df = fs / n

    candidates, structure, peaks, events = _build_candidates(x, fs)
    K = len(candidates)
    centers, raw_bandwidth, bandwidth, nearest_distance, alpha = _effective_bandwidths(candidates, fs, n)
    sigma = haar_noise_scale(x)

    routes = [''] * K
    harmonic = []
    diagnostics = {}
    resolved_kinds = {'ridge', 'modulated', 'dense_multiline', 'trend'}

    for k, candidate in enumerate(candidates):
        if abs(candidate['center']) <= df / 2.0:
            routes[k] = 'S'
            diagnostics[k] = {'structure_resolved': True}
            continue

        if 'multiridge_parent_kind' in candidate:
            routes[k] = 'S'
            diagnostics[k] = {'structure_resolved': True, 'multiridge_child': True}
            continue

        # Best single-harmonic variable projection inside the structure-derived band.
        local_band = np.asarray([bandwidth[k]], float)
        single_wave, _, _ = _variable_projection_vpgn(
            np.asarray(candidate['wave'], float), fs, [candidate], [0],
            effective_bandwidth=local_band
        )
        residual = np.asarray(candidate['wave'], float) - single_wave[0]
        P_res = np.abs(np.fft.rfft(residual)) ** 2
        p_res = P_res / (float(np.sum(P_res)) + EPS)
        nz = p_res > 0
        R_res = max(1.0, math.exp(-float(np.sum(p_res[nz] * np.log(p_res[nz])))))
        occupancy = min(1.0, 2.0 * R_res / n)
        eta = float(np.mean(residual ** 2) / (sigma ** 2 * occupancy + EPS))
        if eta <= 1.0:
            G_res = -float(math.log(max(R_res, 2.0)))
        else:
            G_res = float(
                2.0 * R_res * (eta - 1.0 - math.log(eta))
                - math.log(max(R_res, 2.0))
            )

        if G_res <= 0.0:
            routes[k] = 'H'
            harmonic.append(k)
        elif candidate.get('kind') in resolved_kinds:
            routes[k] = 'S'
        else:
            routes[k] = 'V'

        diagnostics[k] = {
            'single_residual_gain': float(G_res),
            'kind': candidate.get('kind'),
            'raw_bandwidth_Hz': float(raw_bandwidth[k]),
            'effective_bandwidth_Hz': float(bandwidth[k]),
            'single_search_interval_Hz': (
                float(max(0.0, centers[k]-bandwidth[k])),
                float(min(fs/2.0, centers[k]+bandwidth[k]))
            ),
            'nearest_distance_Hz': float(nearest_distance[k]),
        }

    harmonic = sorted(set(harmonic))
    projected = {}
    refined = np.asarray([], float)
    if harmonic:
        projected, refined, _ = _variable_projection_vpgn(
            x, fs, candidates, harmonic, effective_bandwidth=bandwidth
        )

    modes = [None] * K
    vmd_idx = []
    for k, route in enumerate(routes):
        if route == 'H':
            modes[k] = np.asarray(projected[k], float)
        elif route == 'S':
            modes[k] = np.asarray(candidates[k]['wave'], float)
        else:
            vmd_idx.append(k)

    fixed_idx = [k for k in range(K) if k not in vmd_idx]
    residual = x - sum((modes[k] for k in fixed_idx), np.zeros_like(x))
    v_modes, vmd_info = _classical_vmd_three_equations(
        residual,
        fs,
        [candidates[k] for k in vmd_idx],
        alpha[vmd_idx],
    )
    for j, k in enumerate(vmd_idx):
        modes[k] = v_modes[j]

    # Final global least-squares amplitude calibration; modal centers, bandwidths,
    # structural forms, and K remain unchanged.
    U = np.column_stack(modes)
    gamma = np.linalg.lstsq(U, x, rcond=None)[0]
    modes = (U * gamma).T

    info = dict(structure)
    info.update({
        'algorithm_name': 'SGVMD',
        'K': int(K),
        'K_source': 'automatic',
        'candidates': candidates,
        'routes': routes,
        'candidate_centers_Hz': centers,
        'raw_bandwidth_Hz': raw_bandwidth,
        'effective_bandwidth_Hz': bandwidth,
        'nearest_center_distance_Hz': nearest_distance,
        'alpha': alpha,
        'omega0_rad_s': 2.0 * np.pi * centers,
        'refined_harmonic_frequencies_Hz': refined,
        'amplitude_scale': gamma,
        'candidate_diagnostics': diagnostics,
        'vmd': vmd_info,
        'multiridge_events': events,
        'global_significant_peaks_Hz': np.asarray(peaks, float),
    })
    return modes, info
