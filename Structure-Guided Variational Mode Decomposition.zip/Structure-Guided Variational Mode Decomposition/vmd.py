# -*- coding: utf-8 -*-
"""Classical Variational Mode Decomposition (VMD), standalone Python file.

Reference
---------
K. Dragomiretskiy and D. Zosso, "Variational Mode Decomposition",
IEEE Transactions on Signal Processing, vol. 62, no. 3, pp. 531-544, 2014.

This file intentionally contains only the current VMD implementation used by the
29-scenario benchmark and is fully standalone.
"""
from __future__ import annotations

import numpy as np

EPS = np.finfo(float).eps


def run_vmd(
    signal: np.ndarray,
    fs: float,
    K: int,
    alpha: float = 2000.0,
    tau: float = 0.0,
    tol: float = 1e-7,
    max_iter: int = 500,
    dc: bool = False,
):
    """Decompose a real 1-D signal by classical VMD.

    Parameters
    ----------
    signal : ndarray, shape (N,)
        Real-valued input signal.
    fs : float
        Sampling frequency in Hz.  Used only to report centre frequencies in Hz.
    K : int
        Number of modes.  Classical VMD requires K in advance.
    alpha : float
        Common quadratic bandwidth penalty.
    tau : float
        Dual ascent step. tau=0 is the common noisy-signal setting.
    tol : float
        Relative spectral convergence threshold.
    max_iter : int
        Numerical safety limit.
    dc : bool
        If True, keep the first mode at zero centre frequency.

    Returns
    -------
    modes : ndarray, shape (K, N)
    info : dict
        Iteration count, convergence flag, centre frequencies and parameters.
    """
    x = np.asarray(signal, dtype=float).ravel()
    N0 = x.size
    if N0 < 4:
        raise ValueError("signal must contain at least 4 samples")
    if K < 1:
        raise ValueError("K must be >= 1")

    # Standard VMD implementations operate on an even record length.
    # Preserve the original length by padding one sample when necessary.
    odd = N0 % 2
    if odd:
        x_work = np.r_[x, x[-1]]
    else:
        x_work = x.copy()
    N = x_work.size

    # Mirror extension suppresses endpoint discontinuity before the FFT.
    half = N // 2
    x_mirror = np.concatenate([x_work[:half][::-1], x_work, x_work[half:][::-1]])
    T = x_mirror.size

    # Normalised frequency axis in cycles/sample.  Positive frequencies occupy
    # the second half after fftshift, matching the original VMD derivation.
    freqs = np.arange(1, T + 1, dtype=float) / T - 0.5 - 1.0 / T
    f_hat = np.fft.fftshift(np.fft.fft(x_mirror))
    f_hat_plus = f_hat.copy()
    f_hat_plus[: T // 2] = 0.0

    # Uniform initial centre frequencies over [0, Nyquist).
    omega = np.zeros(K, dtype=float)
    if K > 1:
        omega[:] = 0.5 * np.arange(K, dtype=float) / K
    if dc:
        omega[0] = 0.0

    alpha_vec = np.full(K, float(alpha), dtype=float)
    u_hat = np.zeros((T, K), dtype=complex)
    u_prev = np.zeros_like(u_hat)
    lambda_hat = np.zeros(T, dtype=complex)

    converged = False
    for it in range(int(max_iter)):
        u_prev[:] = u_hat

        # Gauss-Seidel modal updates: newly updated lower-index modes and the last-iteration
        # higher-index modes appear in the residual exactly as in classical VMD.
        for k in range(K):
            others = np.sum(u_hat[:, :k], axis=1) + np.sum(u_prev[:, k + 1 :], axis=1)
            u_hat[:, k] = (
                f_hat_plus - others - lambda_hat / 2.0
            ) / (1.0 + alpha_vec[k] * (freqs - omega[k]) ** 2)

            if not (dc and k == 0):
                pos = slice(T // 2, T)
                power = np.abs(u_hat[pos, k]) ** 2
                den = np.sum(power)
                if den > EPS:
                    omega[k] = float(np.sum(freqs[pos] * power) / den)

        # Dual ascent.  tau=0 keeps the common noise-slack formulation.
        lambda_hat = lambda_hat + tau * (np.sum(u_hat, axis=1) - f_hat_plus)

        rel = float(
            np.sum(np.abs(u_hat - u_prev) ** 2)
            / (np.sum(np.abs(u_prev) ** 2) + EPS)
        )
        if rel <= tol and it >= 2:
            converged = True
            break

    # Rebuild Hermitian spectra and transform back to the time domain.
    modes_full = np.zeros((K, T), dtype=float)
    for k in range(K):
        spec = np.zeros(T, dtype=complex)
        spec[T // 2 :] = u_hat[T // 2 :, k]
        # Mirror the strictly positive frequencies.  This indexing mirrors the
        # common vmdpy/PySDKit reconstruction convention.
        spec[1 : T // 2 + 1] = np.conj(u_hat[T - 1 : T // 2 - 1 : -1, k])
        spec[0] = np.conj(spec[-1])
        modes_full[k] = np.real(np.fft.ifft(np.fft.ifftshift(spec)))

    modes = modes_full[:, T // 4 : 3 * T // 4]
    if odd:
        modes = modes[:, :N0]

    # Sort the returned modes by final centre frequency for deterministic output.
    order = np.argsort(omega)
    modes = modes[order]
    omega = omega[order]

    info = {
        "K": int(K),
        "iterations": int(it + 1),
        "converged": bool(converged),
        "alpha": float(alpha),
        "tau": float(tau),
        "center_frequencies_Hz": omega * float(fs),
        "K_source": "oracle",
    }
    return modes, info
