# -*- coding: utf-8 -*-
"""Successive Variational Mode Decomposition (SVMD), standalone Python port.

Reference
---------
M. Nazari and S. M. Sakhaei, "Successive Variational Mode Decomposition",
Signal Processing, 174 (2020) 107610.

Implementation provenance
-------------------------
The authors publish the corrected MATLAB implementation (SVMD.m, v1.1.1) on
MATLAB Central File Exchange.  This standalone NumPy/SciPy implementation keeps
that public algorithm's successive extraction, alpha continuation, four stopping
criteria, mirror extension, and spectral reconstruction.  Array-axis details are
implemented with MATLAB ``sum(matrix)`` semantics (sum over extracted modes), as
also done by the public PySDKit SVMD implementation.

SVMD does not require K in advance.  ``run_svmd`` is the project-facing wrapper;
it returns the automatically extracted modes and reports center frequencies in Hz.
"""
from __future__ import annotations

import numpy as np
from scipy.signal import savgol_filter

EPS = np.finfo(float).eps


def _noise_estimate(signal: np.ndarray) -> np.ndarray:
    """Savitzky-Golay noise estimate used by the public SVMD code."""
    n = signal.size
    win = min(25, n if n % 2 else n - 1)
    if win < 3:
        return np.zeros_like(signal)
    poly = min(8, win - 2)
    smooth = savgol_filter(signal, window_length=win, polyorder=poly)
    return signal - smooth


def svmd(
    signal: np.ndarray,
    max_alpha: float = 20000.0,
    tau: float = 0.0,
    tol: float = 1e-6,
    stopc: int = 4,
    init_omega: int = 0,
    max_iter: int = 300,
    max_modes: int = 30,
    random_seed: int = 42,
):
    """Decompose ``signal`` by Successive Variational Mode Decomposition.

    Parameters mirror the public SVMD implementation.  ``stopc`` is:
      1 residual power vs estimated noise,
      2 exact reconstruction,
      3 Bayesian information criterion,
      4 power of the last mode (default).

    Returns
    -------
    modes : ndarray, shape (L, N)
    u_hat : ndarray, shape (N, L)
    omega : ndarray, shape (L,)
        Normalized center frequencies in cycles/sample.
    info : dict
    """
    x = np.asarray(signal, dtype=float).ravel()
    if x.size < 4:
        raise ValueError("signal must contain at least 4 samples")
    if not np.all(np.isfinite(x)):
        raise ValueError("signal must be finite")
    if max_alpha < 10:
        raise ValueError("max_alpha must be >= 10")
    if tau < 0:
        raise ValueError("tau must be >= 0")
    if tol <= 0:
        raise ValueError("tol must be positive")
    if stopc not in (1, 2, 3, 4):
        raise ValueError("stopc must be one of {1,2,3,4}")
    if init_omega not in (0, 1):
        raise ValueError("init_omega must be 0 or 1")
    if max_iter < 2 or max_modes < 1:
        raise ValueError("max_iter >= 2 and max_modes >= 1 are required")

    original_n = x.size
    # Corrected public Python ports follow the MATLAB intent: an odd record is
    # made even by dropping its last sample.  Project benchmarks are even-length.
    if x.size % 2:
        x = x[:-1]
    save_T = x.size
    signoise = _noise_estimate(x)

    half0 = save_T // 2
    f = np.concatenate((x[:half0][::-1], x, x[half0:][::-1]))
    fnoise = np.concatenate(
        (signoise[:half0][::-1], signoise, signoise[half0:][::-1])
    )
    T = f.size
    half = T // 2
    t = np.arange(1, T + 1, dtype=float) / T
    omega_freqs = t - 0.5 - 1.0 / T

    f_hat = np.fft.fftshift(np.fft.fft(f))
    f_hat_plus = f_hat.copy()
    f_hat_plus[:half] = 0.0
    f_hat_n = np.fft.fftshift(np.fft.fft(fnoise))
    f_hat_n_plus = f_hat_n.copy()
    f_hat_n_plus[:half] = 0.0
    noisepe = float(np.linalg.norm(f_hat_n_plus) ** 2)

    rng = np.random.RandomState(random_seed)
    min_alpha = 10.0
    fs_norm = 1.0 / save_T

    modes_hat: list[np.ndarray] = []
    omega_d: list[float] = []
    alpha_hist: list[float] = []
    h_rows: list[np.ndarray] = []
    polm: list[float] = []
    bic: list[float] = []
    sigerror: list[float] = []
    normind: list[float] = []
    polm_temp = 1.0
    per_mode_iterations: list[int] = []

    stop = False
    mode_idx = 0
    while not stop and mode_idx < int(max_modes):
        Alpha = min_alpha
        omega_L = np.zeros(int(max_iter), dtype=float)
        n2 = 0
        if init_omega == 0 or mode_idx == 0:
            omega_L[0] = 0.0
        else:
            # Public initialization: log-uniform in [1/N, 1/2], avoiding
            # previously extracted centers by at least 0.02 normalized units.
            while n2 < 300:
                cand = float(
                    np.exp(
                        np.log(fs_norm)
                        + (np.log(0.5) - np.log(fs_norm)) * rng.rand()
                    )
                )
                n2 += 1
                if not omega_d or np.min(np.abs(np.asarray(omega_d) - cand)) >= 0.02:
                    omega_L[0] = cand
                    break

        lam = np.zeros((int(max_iter), T), dtype=complex)
        u_hat_L = np.zeros((int(max_iter), T), dtype=complex)
        udiff = tol + EPS
        n = 0
        m = 0.0
        bf = 0
        total_inner = 0
        h_sum = np.sum(np.vstack(h_rows), axis=0) if h_rows else np.zeros(T)
        u_sum = (
            np.sum(np.vstack(modes_hat), axis=0)
            if modes_hat
            else np.zeros(T, dtype=complex)
        )

        # Continuation in alpha, matching the public MATLAB control flow.
        while Alpha < max_alpha + 1.0 and np.isfinite(Alpha):
            while udiff > tol and n < int(max_iter) - 1:
                dw = omega_freqs - omega_L[n]
                dw2 = dw * dw
                inter = (Alpha * Alpha) * (dw2 * dw2)

                numer = f_hat_plus + inter * u_hat_L[n] + lam[n] / 2.0
                denom = (1.0 + inter) * (1.0 + 2.0 * Alpha * dw2) + h_sum
                u_hat_L[n + 1] = numer / (denom + EPS)

                power = np.abs(u_hat_L[n + 1, half:]) ** 2
                psum = float(np.sum(power))
                if psum > EPS:
                    omega_L[n + 1] = float(
                        np.dot(omega_freqs[half:], power) / psum
                    )
                else:
                    omega_L[n + 1] = omega_L[n]

                if tau != 0.0:
                    filter_num = (
                        inter
                        * (f_hat_plus - u_hat_L[n + 1] - u_sum + lam[n] / 2.0)
                        - u_sum
                    )
                    filter_den = 1.0 + inter
                    residual = f_hat_plus - (
                        u_hat_L[n + 1] + filter_num / filter_den + u_sum
                    )
                    lam[n + 1] = lam[n] + tau * residual
                else:
                    lam[n + 1] = lam[n]

                diff = u_hat_L[n + 1] - u_hat_L[n]
                num = np.vdot(diff, diff).real / T
                den = np.vdot(u_hat_L[n], u_hat_L[n]).real / T
                udiff = abs((EPS + num) / (den + EPS))
                n += 1
                total_inner += 1

            if abs(m - np.log(max_alpha)) > 1.0:
                m += 1.0
            else:
                m += 0.05
                bf += 1
            if bf >= 2:
                Alpha += 1.0
            if Alpha <= max_alpha - 1.0:
                if bf == 1:
                    Alpha = max_alpha - 1.0
                else:
                    Alpha = float(np.exp(m))

                omega_keep = float(omega_L[n])
                temp_ud = u_hat_L[n].copy()
                udiff = tol + EPS
                n = 0
                lam.fill(0.0)
                u_hat_L.fill(0.0)
                u_hat_L[0] = temp_ud
                omega_L.fill(0.0)
                omega_L[0] = omega_keep

        mode_spectrum = u_hat_L[n].copy()
        omega_val = float(omega_L[max(n - 1, 0)])
        if omega_val < 0.0:
            omega_val = 0.0
        if omega_val <= 0.0 and n > 0:
            pos = omega_L[omega_L > 0]
            if pos.size:
                omega_val = float(pos[-1])

        modes_hat.append(mode_spectrum)
        omega_d.append(omega_val)
        alpha_hist.append(float(Alpha))
        per_mode_iterations.append(total_inner)

        h_row = 1.0 / (
            (alpha_hist[-1] ** 2) * (omega_freqs - omega_d[-1]) ** 4 + EPS
        )
        h_rows.append(h_row)

        stack = np.vstack(modes_hat)
        residual = f_hat_plus - np.sum(stack, axis=0)

        if stopc == 1:
            val = float(np.linalg.norm(residual) ** 2)
            sigerror.append(val)
            if n2 >= 300 or val <= round(noisepe):
                stop = True
        elif stopc == 2:
            sum_u = np.sum(stack, axis=0)
            val = float(
                (np.linalg.norm(sum_u - f_hat_plus) ** 2 / T)
                / (np.linalg.norm(f_hat_plus) ** 2 / T + EPS)
            )
            normind.append(val)
            if n2 >= 300 or val < 0.005:
                stop = True
        elif stopc == 3:
            se = float(np.linalg.norm(residual) ** 2)
            sigerror.append(se)
            # MATLAB l is 1-based here.
            b = float(2.0 * T * np.log(max(se, EPS)) + 3.0 * (mode_idx + 1) * np.log(2.0 * T))
            bic.append(b)
            if mode_idx >= 1 and bic[-1] > bic[-2]:
                stop = True
        else:
            mode_l = modes_hat[-1]
            omega_l = omega_d[-1]
            filt = (4.0 * Alpha * mode_l) / (
                1.0 + 2.0 * Alpha * (omega_freqs - omega_l) ** 2
            )
            p = float(np.linalg.norm(filt * np.conj(mode_l)))
            if mode_idx == 0:
                polm_temp = p if p != 0.0 else 1.0
                polm.append(1.0)
            else:
                polm.append(p / (polm_temp + EPS))
                # The public PySDKit port uses 1e-3 for this outer-mode
                # power stabilization test; the ADMM tolerance remains ``tol``.
                if abs(polm[-1] - polm[-2]) < 0.001:
                    stop = True

        mode_idx += 1

    if not modes_hat:
        raise RuntimeError("SVMD failed to extract any mode")

    omega = np.asarray(omega_d, dtype=float)
    L = len(modes_hat)
    stacked = np.vstack(modes_hat).T  # (T,L)
    u_hat_full = np.zeros((T, L), dtype=complex)
    u_hat_full[half:T, :] = stacked[half:T, :]
    idxs = np.flip(np.arange(1, half + 1), axis=0)
    u_hat_full[idxs, :] = np.conj(stacked[half:T, :])
    u_hat_full[0, :] = np.conj(u_hat_full[-1, :])

    u = np.zeros((L, T), dtype=float)
    for ell in range(L):
        u[ell] = np.real(np.fft.ifft(np.fft.ifftshift(u_hat_full[:, ell])))

    order = np.argsort(omega)
    omega = omega[order]
    u = u[order]
    u = u[:, T // 4 : 3 * T // 4]

    # Restore odd original length only for API convenience.  This path is not
    # used by the benchmark, whose records are even-length.
    if original_n != save_T:
        u = np.pad(u, ((0, 0), (0, original_n - save_T)), mode="edge")

    u_hat = np.zeros((u.shape[1], L), dtype=complex)
    for ell in range(L):
        u_hat[:, ell] = np.fft.fftshift(np.fft.fft(u[ell]))

    info = {
        "K": int(L),
        "K_source": "automatic",
        "max_alpha": float(max_alpha),
        "tau": float(tau),
        "tol": float(tol),
        "stopc": int(stopc),
        "init_omega": int(init_omega),
        "normalized_center_frequencies": omega.copy(),
        "alpha_history": np.asarray(alpha_hist, dtype=float)[order],
        "per_mode_inner_iterations": np.asarray(per_mode_iterations, dtype=int)[order],
        "stopped_by_criterion": bool(stop),
        "reached_max_modes": bool((not stop) and L >= max_modes),
    }
    return u, u_hat, omega, info


def run_svmd(
    signal: np.ndarray,
    fs: float,
    max_alpha: float = 20000.0,
    tau: float = 0.0,
    tol: float = 1e-6,
    stopc: int = 4,
    init_omega: int = 0,
    max_iter: int = 300,
    max_modes: int = 30,
):
    """Project-facing standalone SVMD wrapper.

    Unlike VMD, no oracle K is supplied.  ``fs`` only converts normalized
    center frequencies to Hz; it does not alter the public SVMD optimization.
    """
    if not np.isfinite(fs) or fs <= 0:
        raise ValueError("fs must be finite and positive")
    modes, _, omega, info = svmd(
        signal,
        max_alpha=max_alpha,
        tau=tau,
        tol=tol,
        stopc=stopc,
        init_omega=init_omega,
        max_iter=max_iter,
        max_modes=max_modes,
    )
    info = dict(info)
    info["center_frequencies_Hz"] = omega * float(fs)
    return modes, info


__all__ = ["svmd", "run_svmd"]
