# -*- coding: utf-8 -*-
"""Original benchmark cases 27-29 (new positions 61-63): SGVMD vs STVMD vs classical VMD.

These are exactly the original three non-stationary STVMD paper environments
(Eqs. 41-43) from benchmark_scenarios.py. Existing SGVMD, STVMD and VMD
algorithm implementations/parameters are unchanged.
"""
from __future__ import annotations

import time
from pathlib import Path
import numpy as np
import pandas as pd

from benchmark_scenarios import all_benchmark_cases, matched_metrics, center_frequency_mae
from sgvmd import run_sgvmd
from stvmd import run_stvmd
from vmd import run_vmd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)


def _as_2d(a):
    a = np.asarray(a, dtype=float)
    return a[None, :] if a.ndim == 1 else a


def _centers_text(info):
    for key in ("candidate_centers_Hz", "center_frequencies_Hz"):
        if key in info:
            return ";".join(f"{v:.9g}" for v in np.asarray(info[key], float).ravel())
    return ""


def _summary(df):
    rows = []
    for alg, g in df.groupby("algorithm", sort=False):
        auto = g["automatic_K_correct"].dropna()
        rows.append({
            "algorithm": alg,
            "K_source": g["K_source"].iloc[0],
            "automatic_K_accuracy": float(auto.mean()) if len(auto) else np.nan,
            "mean_truth_corr": float(g["mean_truth_corr"].mean()),
            "mean_component_NRMSE": float(g["mean_component_NRMSE"].mean()),
            "clean_reconstruction_NRMSE": float(g["clean_reconstruction_NRMSE"].mean()),
            "center_frequency_MAE_Hz": float(g["center_frequency_MAE_Hz"].mean()),
            "median_runtime_s": float(g["runtime_s"].median()),
            "failed_cases": int(g["error"].astype(bool).sum()),
        })
    return pd.DataFrame(rows)


def main():
    cases = all_benchmark_cases()[60:63]
    if len(cases) != 3:
        raise RuntimeError(f"Expected 3 cases, got {len(cases)}")

    rows = []
    for local_idx, case in enumerate(cases, 1):
        global_idx = 60 + local_idx
        x = np.asarray(case["input_signal"], float)
        truth = np.asarray(case["truth"], float)
        fs = float(case["fs"])
        true_k = int(truth.shape[0])

        jobs = [
            ("SGVMD", "automatic", lambda: run_sgvmd(x, fs)),
            ("STVMD", "oracle", lambda: run_stvmd(
                x, fs, physical_K=true_k, paper_exact=True,
                window_length=int(case.get("stvmd_window", 64)))),
            ("VMD", "oracle", lambda: run_vmd(
                x, fs, K=true_k + 1, alpha=50.0, tau=1e-5,
                tol=1e-9, max_iter=500, dc=True)),
        ]

        print(f"[{local_idx:02d}/3 | global {global_idx:02d}] {case['slug']}", flush=True)
        for algorithm, k_source, runner in jobs:
            t0 = time.perf_counter()
            err = ""
            info = {}
            try:
                modes, info = runner()
                runtime = time.perf_counter() - t0
                modes = _as_2d(modes)
                L = min(len(x), modes.shape[1])
                modes = modes[:, :L]
                truth_eval = truth[:, :L]
                met = matched_metrics(truth_eval, modes)
                cf = center_frequency_mae(truth_eval, modes, fs)
                out_k = int(len(modes))
                auto_ok = float(out_k == true_k) if algorithm == "SGVMD" else np.nan
                iterations = (
                    info.get("vmd", {}).get("iterations", "")
                    if algorithm == "SGVMD"
                    else info.get("iterations", "")
                )
            except Exception as exc:
                runtime = time.perf_counter() - t0
                met = {
                    "mean_truth_corr": np.nan,
                    "min_truth_corr": np.nan,
                    "mean_component_NRMSE": np.nan,
                    "clean_reconstruction_NRMSE": np.nan,
                    "matched_mode_indices": "",
                }
                cf = np.nan
                out_k = 0
                auto_ok = np.nan
                iterations = ""
                err = f"{type(exc).__name__}: {exc}"

            rows.append({
                "case": global_idx,
                "domain": case["domain"],
                "scenario": case["scenario"],
                "slug": case["slug"],
                "Fs_Hz": fs,
                "N": len(x),
                "algorithm": algorithm,
                "K_source": k_source,
                "true_K": true_k,
                "output_mode_count": out_k,
                "automatic_K_correct": auto_ok,
                "mean_truth_corr": met["mean_truth_corr"],
                "min_truth_corr": met["min_truth_corr"],
                "mean_component_NRMSE": met["mean_component_NRMSE"],
                "clean_reconstruction_NRMSE": met["clean_reconstruction_NRMSE"],
                "center_frequency_MAE_Hz": cf,
                "runtime_s": runtime,
                "iterations": iterations,
                "hop_length": info.get("hop_length", "") if not err else "",
                "routes": ";".join(info.get("routes", [])) if algorithm == "SGVMD" and not err else "",
                "center_frequencies_Hz": _centers_text(info) if not err else "",
                "matched_mode_indices": met["matched_mode_indices"],
                "error": err,
            })

    df = pd.DataFrame(rows)
    results_path = OUT / "last3_sgvmd_stvmd_vmd_results.csv"
    summary_path = OUT / "last3_sgvmd_stvmd_vmd_summary.csv"
    df.to_csv(results_path, index=False, encoding="utf-8-sig")
    summary = _summary(df)
    summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
    print("\nSUMMARY")
    print(summary.to_string(index=False))
    print(f"\nSaved: {results_path}")
    print(f"Saved: {summary_path}")


if __name__ == "__main__":
    main()
