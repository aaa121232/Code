# -*- coding: utf-8 -*-
"""Short-Time Variational Mode Decomposition (STVMD).

This module replaces the earlier hand-written approximation with an
open-source-reference-compatible implementation of Jia et al.,
"Short-time variational mode decomposition", Signal Processing 238 (2026)
110203.

Compatibility target
--------------------
The numerical framing / overlap-add / iteration conventions in this file are
aligned with the public STVMD implementation exposed by PySDKit, whose source
explicitly names the authors' GitHub repository as its reference
implementation.  The defaults also match the authors' public README:
K=3 (including the zero-frequency residual), n_fft=64, alpha=50,
tau=1e-5, tol=1e-9, Hamming window and one-sample frame shifts.

Important notation note
-----------------------
The July-2026 corrigendum writes the modal Wiener denominator as
``1 + 2*alpha*(omega-omega_k)^2``.  The released/open-source numerical code
uses ``1 + alpha*(...)^2`` with the published/default ``alpha=50``; that
numerical convention is what reproduces the reported synthetic performance
most closely.  This module therefore follows the executable open-source
convention, rather than silently doubling the effective penalty.

Benchmark compatibility
-----------------------
The project benchmark historically supplies ``physical_K`` (non-DC modes).
The compatibility wrapper ``run_stvmd`` therefore constructs internal
``K=physical_K+1`` and returns only non-DC modes while exposing the residual
and full reconstruction in ``info``.  SGVMD and classical VMD are untouched.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional, Tuple, Union

import numpy as np
from numpy.lib.stride_tricks import as_strided
from scipy.fft import irfft, rfft
from scipy.signal import windows as sigwindows

EPS = np.finfo(float).eps


@dataclass
class STVMDResult:
    """Compatibility result returned by :func:`stvmd_dynamic`."""

    modes: np.ndarray              # (physical_K, N)
    residual: np.ndarray           # (N,)
    centers_Hz: np.ndarray         # dynamic: (physical_K, N_frames)
    residual_center_Hz: np.ndarray # (N_frames,)
    n_iter: int
    convergence: float
    times_s: np.ndarray
    reconstruction: np.ndarray


def _resolve_window(n_fft: int, window: Optional[Union[str, np.ndarray]]) -> np.ndarray:
    if window is None:
        window = "hamming"
    if isinstance(window, str):
        name = window.lower()
        if name == "hamming":
            return sigwindows.hamming(n_fft, sym=False)
        if name == "hann":
            return sigwindows.hann(n_fft, sym=False)
        if name == "boxcar":
            return sigwindows.boxcar(n_fft)
        if name == "dpss":
            return sigwindows.dpss(n_fft, max(4, n_fft // 8), sym=False)
        raise ValueError(
            f"Unknown window {window!r}; use hamming/hann/boxcar/dpss or an array"
        )
    w = np.asarray(window, dtype=float).ravel()
    if w.size != n_fft:
        raise ValueError(f"window length must be {n_fft}, got {w.size}")
    return w


def _pad_width(n_fft: int) -> Tuple[int, int]:
    """Reference reflective padding; even n_fft=64 -> (32, 31)."""
    half = (n_fft - 1) // 2
    if (n_fft - 1) % 2 == 0:
        return half, half
    return half + 1, half


def _buffer(x: np.ndarray, n_fft: int, hop_len: int = 1) -> np.ndarray:
    """Frame a (C,T) array into (C,n_fft,n_frames) with a one-sample hop."""
    C, T = x.shape
    if T < n_fft:
        raise ValueError(f"signal length ({T}) must be >= n_fft ({n_fft})")
    n_frames = (T - n_fft) // hop_len + 1
    s0, s1 = x.strides
    framed = as_strided(
        x,
        shape=(C, n_fft, n_frames),
        strides=(s0, s1, s1 * hop_len),
        writeable=False,
    )
    return np.array(framed, copy=True)


def _unbuffer(xbuf: np.ndarray, window: np.ndarray, hop_len: int = 1,
              win_exp: int = 1) -> np.ndarray:
    """Reference weighted overlap-add used in the open-source implementation."""
    if xbuf.ndim == 2:
        xbuf = xbuf[np.newaxis, ...]
    C, n_fft, n_frames = xbuf.shape
    if win_exp == 0:
        w = np.ones(n_fft, dtype=float)
    elif win_exp == 1:
        w = window
    else:
        w = window ** win_exp
    T = n_fft + (n_frames - 1) * hop_len
    out = np.zeros((C, T), dtype=xbuf.dtype)
    for i in range(n_frames):
        start = i * hop_len
        out[:, start:start + n_fft] += xbuf[:, :, i] * w
    return out


def _window_norm(window: np.ndarray, hop_len: int, n_fft: int,
                 n_frames: int, win_exp: int = 1) -> np.ndarray:
    """Normalize analysis+synthesis windows (default: sum of Hamming^2)."""
    T = n_fft + (n_frames - 1) * hop_len
    norm = np.zeros(T, dtype=float)
    wpow = window ** (win_exp + 1)
    for i in range(n_frames):
        start = i * hop_len
        norm[start:start + n_fft] += wpow
    return np.maximum(norm, EPS)


class STVMD:
    """Open-source-compatible Short-Time Variational Mode Decomposition.

    Parameters
    ----------
    K : int
        Total number of modes, INCLUDING the zero-frequency residual.
    alpha : float
        Bandwidth penalty in the released numerical implementation.
    n_fft : int
        STFT window/FFT length.  The paper uses 64 in the synthetic tests.
    tau : float
        Dual ascent step.
    tol : float
        Spectral update convergence tolerance.
    max_iter : int
        Maximum ADMM iterations; public library default is 500.
    dynamic : bool
        If True, each frame has time-varying centre frequencies.
    window : str or ndarray
        Analysis window.  Default is periodic Hamming.
    win_exp : int
        Synthesis-window exponent.  Default 1 gives Hamming^2 normalization.
    init_omega : ndarray, optional
        Non-dynamic centre-frequency initialization.  If provided, centers
        are kept fixed, matching the reference implementation behaviour.
    """

    def __init__(
        self,
        K: int = 3,
        alpha: float = 50.0,
        n_fft: int = 64,
        tau: float = 1e-5,
        tol: float = 1e-9,
        max_iter: int = 500,
        dynamic: bool = False,
        window: Optional[Union[str, np.ndarray]] = "hamming",
        win_exp: int = 1,
        init_omega: Optional[np.ndarray] = None,
    ) -> None:
        if K < 1:
            raise ValueError("K must be >= 1")
        if n_fft < 4:
            raise ValueError("n_fft must be >= 4")
        if alpha <= 0:
            raise ValueError("alpha must be positive")
        if max_iter < 2:
            raise ValueError("max_iter must be >= 2")

        self.K = int(K)
        self.alpha = float(alpha) * np.ones(self.K, dtype=float)
        self.n_fft = int(n_fft)
        self.hop_len = 1  # reference implementation: fixed one-sample shift
        self.tau = float(tau)
        self.tol = float(tol)
        self.max_iter = int(max_iter)
        self.dynamic = bool(dynamic)
        self.win_exp = int(win_exp)
        self.window = _resolve_window(self.n_fft, window)
        self.padwidth = _pad_width(self.n_fft)
        self.freqs = np.arange(1, self.n_fft // 2 + 2, dtype=float) / (
            self.n_fft // 2 + 1
        )
        self.init_omega = (
            None if init_omega is None else np.asarray(init_omega, dtype=float).ravel()
        )
        if self.init_omega is not None and self.init_omega.size != self.K:
            raise ValueError("init_omega must have length K")

        self.signal: Optional[np.ndarray] = None
        self.u: Optional[np.ndarray] = None
        self.u_hat: Optional[np.ndarray] = None
        self.omega: Optional[np.ndarray] = None
        self.n_iter: Optional[int] = None
        self.convergence: Optional[float] = None
        self._input_was_1d = True

    def __call__(self, signal: np.ndarray, return_all: bool = False):
        return self.fit_transform(signal, return_all=return_all)

    def _prepare(self, signal: np.ndarray) -> np.ndarray:
        x = np.asarray(signal, dtype=float)
        if x.ndim == 1:
            self._input_was_1d = True
            x = x.reshape(1, -1)
        elif x.ndim == 2:
            self._input_was_1d = False
        else:
            raise ValueError("signal must be 1-D or 2-D with shape (C,T)")
        if x.shape[-1] < self.n_fft:
            raise ValueError(
                f"signal length ({x.shape[-1]}) must be >= n_fft ({self.n_fft})"
            )
        xp = np.pad(x, ((0, 0), self.padwidth), mode="reflect")
        frames = _buffer(xp, self.n_fft, self.hop_len)
        frames *= self.window.reshape(1, -1, 1)
        return rfft(frames, axis=1)

    def _postprocess(self, u_hat: np.ndarray) -> np.ndarray:
        C, _, K, n_frames = u_hat.shape
        norm = _window_norm(
            self.window, self.hop_len, self.n_fft, n_frames, self.win_exp
        )
        full_len = self.n_fft + n_frames - 1
        modes = np.zeros((K, C, full_len), dtype=float)
        for k in range(K):
            xbuf = irfft(u_hat[:, :, k, :], n=self.n_fft, axis=1).real
            modes[k] = _unbuffer(xbuf, self.window, self.hop_len, self.win_exp)
        modes /= norm.reshape(1, 1, -1)
        left, right = self.padwidth
        if right:
            modes = modes[:, :, left:-right]
        else:
            modes = modes[:, :, left:]
        return modes

    def _init_omega_vector(self) -> Tuple[np.ndarray, bool]:
        if self.init_omega is not None:
            return self.init_omega.copy(), True
        return np.arange(self.K, dtype=float) / float(self.K), False

    @staticmethod
    def _update_measure(u_hat: np.ndarray, old: np.ndarray) -> float:
        # Reference library convergence metric: spectral mean-square update,
        # reduced over frequency and frames, then max over channel/mode blocks.
        delta = u_hat - old
        udiff = np.mean(np.abs(delta) ** 2, axis=1)  # (C,K,N_frames)
        return float(np.max(np.mean(udiff, axis=-1)))

    def _admm_nodynamic(self, f_hat: np.ndarray):
        C, F, N = f_hat.shape
        freqs = self.freqs if self.freqs.size == F else np.arange(1, F + 1) / F
        omega, freeze = self._init_omega_vector()
        u_hat = np.zeros((C, F, self.K, N), dtype=complex)
        old = np.zeros_like(u_hat)
        sum_uk = np.zeros((C, F, N), dtype=complex)
        lambda_hat = np.zeros((C, F, N), dtype=complex)
        conv = np.inf
        n_iter = 0

        for n_iter in range(1, self.max_iter):
            # Gauss-Seidel update, using the same dual-sign convention as the
            # packaged open-source implementation.
            sum_uk = old[:, :, self.K - 1, :] + sum_uk - old[:, :, 0, :]
            den = 1.0 + self.alpha[0] * (freqs.reshape(1, -1, 1) - omega[0]) ** 2
            u_hat[:, :, 0, :] = (f_hat - sum_uk - lambda_hat / 2.0) / den

            for k in range(1, self.K):
                sum_uk = u_hat[:, :, k - 1, :] + sum_uk - old[:, :, k, :]
                den = 1.0 + self.alpha[k] * (
                    freqs.reshape(1, -1, 1) - omega[k]
                ) ** 2
                u_hat[:, :, k, :] = (f_hat - sum_uk - lambda_hat / 2.0) / den
                if not freeze:
                    power = np.abs(u_hat[:, :, k, :]) ** 2
                    denp = np.sum(power)
                    if denp > 0:
                        omega[k] = float(
                            np.sum(freqs.reshape(1, -1, 1) * power) / denp
                        )

            lambda_hat = lambda_hat + self.tau * (np.sum(u_hat, axis=2) - f_hat)
            conv = self._update_measure(u_hat, old)
            old = u_hat.copy()
            if conv < self.tol and n_iter > 2:
                break

        order = np.argsort(omega)
        return u_hat[:, :, order, :], omega[order], n_iter, conv

    def _admm_dynamic(self, f_hat: np.ndarray):
        C, F, N = f_hat.shape
        freqs = np.arange(1, F + 1, dtype=float) / float(F)
        omega = np.repeat(
            (np.arange(self.K, dtype=float) / float(self.K))[:, None], N, axis=1
        )
        u_hat = np.zeros((C, F, self.K, N), dtype=complex)
        old = np.zeros_like(u_hat)
        sum_uk = np.zeros((C, F, N), dtype=complex)
        lambda_hat = np.zeros((C, F, N), dtype=complex)
        conv = np.inf
        n_iter = 0

        for n_iter in range(1, self.max_iter):
            # k=0 is the zero-frequency residual; its center is never updated.
            sum_uk = old[:, :, self.K - 1, :] + sum_uk - old[:, :, 0, :]
            den = 1.0 + self.alpha[0] * (
                freqs.reshape(1, -1, 1) - omega[0].reshape(1, 1, -1)
            ) ** 2
            u_hat[:, :, 0, :] = (f_hat - sum_uk - lambda_hat / 2.0) / den

            for k in range(1, self.K):
                sum_uk = u_hat[:, :, k - 1, :] + sum_uk - old[:, :, k, :]
                den = 1.0 + self.alpha[k] * (
                    freqs.reshape(1, -1, 1) - omega[k].reshape(1, 1, -1)
                ) ** 2
                u_hat[:, :, k, :] = (f_hat - sum_uk - lambda_hat / 2.0) / den

                power = np.abs(u_hat[:, :, k, :]) ** 2
                num = np.sum(freqs.reshape(1, -1, 1) * power, axis=(0, 1))
                denp = np.sum(power, axis=(0, 1))
                valid = denp > 0
                omega[k, valid] = num[valid] / denp[valid]
            omega[0, :] = 0.0

            lambda_hat = lambda_hat + self.tau * (np.sum(u_hat, axis=2) - f_hat)
            conv = self._update_measure(u_hat, old)
            old = u_hat.copy()
            if conv < self.tol and n_iter > 2:
                break

        # Reference behaviour: order modes independently in each frame.
        order = np.argsort(omega, axis=0)
        u_sorted = np.empty_like(u_hat)
        omega_sorted = np.empty_like(omega)
        for n in range(N):
            u_sorted[:, :, :, n] = u_hat[:, :, order[:, n], n]
            omega_sorted[:, n] = omega[order[:, n], n]
        return u_sorted, omega_sorted, n_iter, conv

    def fit_transform(
        self,
        signal: np.ndarray,
        return_all: bool = False,
        dynamic: Optional[bool] = None,
    ):
        use_dynamic = self.dynamic if dynamic is None else bool(dynamic)
        f_hat = self._prepare(signal)
        if use_dynamic:
            u_hat, omega, n_iter, conv = self._admm_dynamic(f_hat)
        else:
            u_hat, omega, n_iter, conv = self._admm_nodynamic(f_hat)
        u = self._postprocess(u_hat)
        if self._input_was_1d:
            u = u[:, 0, :]

        self.signal = np.asarray(signal, dtype=float)
        self.u = u
        self.u_hat = u_hat
        self.omega = omega
        self.n_iter = n_iter
        self.convergence = conv
        if return_all:
            return u, u_hat, omega
        return u


def stvmd(
    signal: np.ndarray,
    K: int = 3,
    alpha: float = 50.0,
    n_fft: int = 64,
    tau: float = 1e-5,
    tol: float = 1e-9,
    max_iter: int = 500,
    dynamic: bool = False,
    window: Optional[Union[str, np.ndarray]] = "hamming",
    return_all: bool = False,
):
    """Functional interface matching the packaged open-source STVMD API."""
    return STVMD(
        K=K,
        alpha=alpha,
        n_fft=n_fft,
        tau=tau,
        tol=tol,
        max_iter=max_iter,
        dynamic=dynamic,
        window=window,
    ).fit_transform(signal, return_all=return_all)


def stvmd_dynamic(
    signal,
    physical_K,
    fs=1.0,
    window_length=64,
    hop_length=1,
    alpha=50.0,
    tau=1e-5,
    tol=1e-9,
    max_iter=500,
):
    """Project-compatibility wrapper around reference-style dynamic STVMD.

    ``physical_K`` excludes the zero-frequency residual.  The reference
    algorithm always uses one-sample frame shifts; non-unit ``hop_length`` is
    intentionally rejected instead of silently changing the algorithm.
    """
    x = np.asarray(signal, dtype=float).ravel()
    N = x.size
    L = max(4, min(int(window_length), N))
    if int(hop_length) != 1:
        raise ValueError(
            "Open-source-reference STVMD uses hop_length=1; "
            f"received {hop_length}."
        )
    model = STVMD(
        K=int(physical_K) + 1,
        alpha=alpha,
        n_fft=L,
        tau=tau,
        tol=tol,
        max_iter=max_iter,
        dynamic=True,
        window="hamming",
        win_exp=1,
    )
    all_modes, _, omega = model.fit_transform(x, return_all=True)
    residual = all_modes[0].copy()
    physical = all_modes[1:].copy()
    reconstruction = np.sum(all_modes, axis=0)
    centers_hz = omega[1:] * float(fs) / 2.0
    residual_center = omega[0] * float(fs) / 2.0
    times = np.arange(omega.shape[-1], dtype=float) / float(fs)
    return STVMDResult(
        modes=physical,
        residual=residual,
        centers_Hz=centers_hz,
        residual_center_Hz=residual_center,
        n_iter=int(model.n_iter or 0),
        convergence=float(model.convergence if model.convergence is not None else np.nan),
        times_s=times,
        reconstruction=reconstruction,
    )


def run_stvmd(signal, fs, physical_K, paper_exact=False, window_length=64):
    """Benchmark wrapper; always executes the public-reference STVMD path.

    ``paper_exact`` is retained only for backward API compatibility.  The old
    implementation used it to switch between hop=1 and hop=L/2.  The public
    STVMD implementation has a fixed one-sample hop, so both values now run
    the same algorithm.
    """
    L = max(4, min(int(window_length), len(signal)))
    t0 = time.perf_counter()
    res = stvmd_dynamic(
        signal,
        physical_K,
        fs=fs,
        window_length=L,
        hop_length=1,
        alpha=50.0,
        tau=1e-5,
        tol=1e-9,
        max_iter=500,
    )
    runtime = time.perf_counter() - t0
    center_summary = (
        np.median(res.centers_Hz, axis=1)
        if res.centers_Hz.ndim == 2
        else np.asarray(res.centers_Hz, dtype=float)
    )
    info = {
        "runtime_s": runtime,
        "supplied_physical_K": int(physical_K),
        "internal_K_with_zero_residual": int(physical_K) + 1,
        "window_length": L,
        "hop_length": 1,
        "alpha": 50.0,
        "tau": 1e-5,
        "tol": 1e-9,
        "max_iter": 500,
        "iterations": res.n_iter,
        "convergence": res.convergence,
        "centers_Hz": res.centers_Hz,
        "center_frequencies_Hz": center_summary,
        "residual": res.residual,
        "reconstruction_with_residual": res.reconstruction,
        "paper_exact_stride": True,
        "implementation_profile": "open_source_reference_compatible",
    }
    return res.modes, info
